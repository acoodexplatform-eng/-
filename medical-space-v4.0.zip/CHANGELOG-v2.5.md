# Medical Space v2.6

## Official Course Catalog
- Integrated the 34 official courses/workshops/programs supplied by the platform administration.
- Added catalog metadata: category, program type, instructor, lecture count, duration, study method, attendance, certificate status, and availability status.
- Added the supplied topics as structured curriculum entries while preserving the stated lecture counts separately where the two differ.
- Preserved unspecified values as `غير محدد` / `غير محددة` rather than inventing data.
- Marked Chemical Peeling Basics as `قريبًا`.
- Added the three stated PDF attachment descriptions to Cosmetic Formulation.
- Replaced the old illustrative course-directory messaging with the official catalog interface.
- Added bilingual catalog cards with search/filter support and richer course metadata.

## Backend / Production Hardening
- Health version updated to 2.5.
- Added catalog metadata migrations for existing databases.
- Existing older databases receive missing official catalog records without deleting existing administrative content.
- Added additional security response headers: Permissions-Policy and Cross-Origin-Opener-Policy.
- Preserved CSP, X-Content-Type-Options, Referrer-Policy, and X-Frame-Options.

## Important content note
The catalog data contains program topics supplied by administration. Actual lecture media/files remain an administrative content-management task and should be uploaded through the admin dashboard before treating topic placeholders as full learning materials.
