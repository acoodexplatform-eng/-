# MEDICAL SPACE v2.1

Payment and enrollment workflow for paid courses.

### Local run
```bash
python server/app.py
```
Open `http://127.0.0.1:8000`.

### Payment flow
1. Admin publishes a paid course.
2. Admin sets its price, currency, and payment instructions from `admin.html`.
3. Student opens the course and continues to `payment.html`.
4. Student submits payment method + transaction/reference number.
5. Admin reviews the request.
6. Approval activates enrollment; rejection keeps it pending.

### Live payment gateways
No live gateway is connected in v2.1. This is intentional because no provider, merchant account, credentials, webhook contract, or deployment environment was supplied. Integrating one requires provider-specific configuration and production HTTPS/webhook validation.
