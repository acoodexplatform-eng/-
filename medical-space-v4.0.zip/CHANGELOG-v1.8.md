# MEDICAL SPACE v1.8

## Learning system
- Published-course API and bilingual course catalog.
- Structured modules and lessons stored in `assets/data/courses.json`.
- Course detail page with lesson list and access state.
- Free enrollment activates immediately; paid enrollment is pending administration approval.
- Student progress persisted in SQLite via `lesson_progress`.
- Completion percentage and completed lesson state on the course page.
- WhatsApp enrollment/inquiry fallback.
- Course learning content is exposed through the course API only to students with active enrollment; non-enrolled users receive locked lesson metadata.
- Existing authentication, admin, quizzes, certificates, backups, and profile/password functionality preserved.

## Verification
- Python syntax check passed.
- JavaScript syntax checks passed for all JS files.
- Local HTTP smoke test passed for health, course listing, registration, login, enrollment, course access, lesson completion, and progress persistence.

## Not production yet
- Real video/audio/PDF storage and delivery are not connected to external media storage.
- Payment gateway is not connected.
- Production HTTPS/server configuration and deployment still belong to later stages.
