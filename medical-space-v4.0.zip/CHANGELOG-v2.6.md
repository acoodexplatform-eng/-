# Medical Space v2.6

## Final production-preparation pass

- Final security and deployment audit.
- Health endpoint updated to 2.6.
- HSTS enabled automatically when `COOKIE_SECURE=1`.
- Added additional browser security headers.
- Added registration rate limiting alongside login protection.
- Added upload file-signature validation for supported media formats.
- Blocked direct access to private/backups paths.
- Removed generated Python bytecode from the release package.
- Verified Python and JavaScript syntax.
- Verified backup creation and database integrity on a temporary test database.
- Confirmed official 34-program catalog remains intact.

## Deployment boundary

This release is production-preparation, not a hosted deployment. A real deployment still requires a production WSGI/ASGI or equivalent application server, HTTPS reverse proxy, external persistent storage/backups, and operator-managed secrets.
