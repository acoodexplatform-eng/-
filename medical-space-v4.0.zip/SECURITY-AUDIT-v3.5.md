# Medical Space v3.5 — Security Audit

## Implemented hardening
- Expired session cleanup during startup.
- Session cookies use `HttpOnly` and `SameSite=Strict`; `Secure` is enabled when `COOKIE_SECURE=1`.
- CSRF validation on authenticated POST mutations.
- Same-origin validation when an `Origin` header is present.
- Global mutation rate limiting in addition to login/register protection.
- Strict JSON request size limit for API mutations.
- Upload size, MIME allowlist and file-signature validation.
- Upload rollback removes the stored file if the database transaction fails.
- Protected media is authenticated and enrollment-checked; protected media is served with `Cache-Control: private, no-store`.
- Security response headers include CSP, HSTS when enabled, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy, COOP, CORP and X-Permitted-Cross-Domain-Policies.
- API and protected media responses are marked `X-Robots-Tag: noindex, nofollow, noarchive`.
- Server/private/test/backup/data paths remain blocked from public HTTP access.
- Passwords use `scrypt` with per-user random salts.
- Admin promotion is CLI-only and requires explicit confirmation.
- Database backup command remains available and backup files are created with restricted permissions.

## Production requirements still external to this codebase
- Deploy behind a trusted HTTPS reverse proxy.
- Set `COOKIE_SECURE=1` and a fixed `PUBLIC_BASE_URL=https://...`.
- Use a persistent private data directory with filesystem permissions restricted to the service account.
- Configure automated encrypted off-site backups and restore testing.
- Add a production WAF/reverse-proxy rate limit and request body limit in front of the application.
- Rotate secrets when the deployment environment is created or compromised.
- Run dependency/OS patching and an external penetration test before handling real student/payment data.
- Use a real payment gateway only after provider credentials, webhooks and reconciliation rules are configured.
