# MEDICAL SPACE v2.0

## Certificates & verification
- Added public certificate verification API: `/api/certificate/verify/{certificate_id}`.
- Added bilingual verification page: `certificate.html`.
- Improved certificate PDF with bilingual course/student information, result, issue date and verification ID.
- Certificate IDs remain unique 24-character hexadecimal identifiers.
- Administration can issue a certificate only for a passed attempt.
- Duplicate certificates for the same student/course are blocked.
- Student dashboard now exposes certificate verification.
- Health endpoint reports version 2.0.

## Validation
- Python syntax compilation passed.
- Next step still requires full browser/mobile QA and production deployment checks.
