# MEDICAL SPACE v4.0 — Production & Deployment

v4.0 is the production-deployment package. It does **not** claim that a public server, domain, DNS, or certificate has already been configured.

## Required values
Create `.env.production` from `.env.production.example` and set:
- `PUBLIC_BASE_URL=https://YOUR-REAL-DOMAIN`
- `COOKIE_SECURE=1`
- `MEDICAL_SPACE_DATA=/var/lib/medical-space`

## Recommended deployment
1. Provision a Linux server with Python 3.10+ or Docker.
2. Point the domain DNS A/AAAA record to the server.
3. Upload the project outside the public web root.
4. Create a dedicated `medicalspace` OS user.
5. Create `/var/lib/medical-space` and restrict it to the service user.
6. Install Python dependencies from `requirements.txt`.
7. Configure `.env.production`.
8. Start the application behind Nginx using `deploy/systemd/medical-space.service`, or use `docker-compose.production.yml`.
9. Install a trusted TLS certificate and configure Nginx for HTTPS.
10. Confirm `/api/health`, `/robots.txt`, and `/sitemap.xml` use the real HTTPS origin.
11. Create/promote the first admin account and immediately use a strong unique password.
12. Schedule `scripts/backup.sh` daily and periodically test `scripts/restore.sh` on a separate copy.
13. Run the production smoke checklist below.

## HTTPS checklist
- HTTP redirects to HTTPS.
- `COOKIE_SECURE=1`.
- HSTS enabled after HTTPS is confirmed.
- Certificate renewal is automated.
- `PUBLIC_BASE_URL` exactly matches the canonical domain.

## Smoke test
- Home page
- Arabic/English switch
- Registration
- Login/logout
- Student dashboard
- Course enrollment
- Lesson/media access
- Sequential lesson completion
- Quiz submission and result
- Certificate PDF + verification
- Payment request/approval
- Notifications
- Admin dashboard/reports
- Media upload/download
- `/api/health`
- `/robots.txt`
- `/sitemap.xml`

## Operational requirements
- Monitor disk usage in `/var/lib/medical-space` because uploaded media can reach 60 MB per file.
- Back up the SQLite database and the `media/` directory; database-only backups do not restore uploaded media.
- Do not expose `/var/lib/medical-space` through Nginx.
- Keep OS, Python, and dependencies patched.
- Add an external/shared rate limiter if traffic grows beyond a single instance.
- Configure a real password-reset provider before offering password recovery publicly.
- Configure an approved payment gateway only after the payment workflow is finalized.

## Important limitation
The application currently uses its own threaded HTTP server. Nginx should sit in front of it for TLS, request-size limits, buffering, and public exposure. For horizontal scaling, move to a production WSGI/ASGI architecture and shared database/storage/rate limiting.
