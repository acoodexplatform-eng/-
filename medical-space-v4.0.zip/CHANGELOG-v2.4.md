# v2.4

- Advanced student learning flow.
- Sequential lesson unlocking.
- Server-side enforcement of lesson order.
- Progress percentage and lesson summary.
- Integrated media player layout.
- Quiz locked until all lessons are complete.
- Updated API health version to 2.4.
