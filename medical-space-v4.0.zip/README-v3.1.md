# Medical Space v3.1

## Course & Content Experience
The v3.1 release upgrades the learner course page into a focused learning workspace while preserving the existing database, enrollment, sequential progress, quiz and certificate systems.

### Highlights
- Focused lesson viewer.
- Video, audio, PDF, image and text content support.
- Previous/next navigation.
- Complete lesson action and automatic next-lesson opening.
- Module completion states.
- Responsive mobile layout.

This release is a development package and is not a production deployment.
