#!/usr/bin/env bash
set -euo pipefail
DATA_DIR="${MEDICAL_SPACE_DATA:-/var/lib/medical-space}"
BACKUP_DIR="$DATA_DIR/backups"
mkdir -p "$BACKUP_DIR"
python3 server/app.py backup
# Keep the newest 30 database backups.
ls -1t "$BACKUP_DIR"/medical-space-*.sqlite3 2>/dev/null | tail -n +31 | xargs -r rm -f
