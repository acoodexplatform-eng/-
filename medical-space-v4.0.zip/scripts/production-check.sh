#!/usr/bin/env bash
set -euo pipefail
: "${PUBLIC_BASE_URL:?Set PUBLIC_BASE_URL}"
: "${MEDICAL_SPACE_DATA:?Set MEDICAL_SPACE_DATA}"
case "$PUBLIC_BASE_URL" in https://*) ;; *) echo "PUBLIC_BASE_URL must use HTTPS"; exit 1;; esac
python3 -m py_compile server/app.py
python3 server/app.py backup
curl -fsS http://127.0.0.1:${PORT:-8000}/api/health
printf '\nProduction readiness checks passed.\n'
