#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 1 ]; then echo "Usage: $0 /path/to/backup.sqlite3"; exit 2; fi
DATA_DIR="${MEDICAL_SPACE_DATA:-/var/lib/medical-space}"
mkdir -p "$DATA_DIR"
cp --preserve=mode,ownership,timestamps "$1" "$DATA_DIR/medical_space.sqlite3"
chmod 600 "$DATA_DIR/medical_space.sqlite3"
echo "Database restored. Restart the Medical Space service."
