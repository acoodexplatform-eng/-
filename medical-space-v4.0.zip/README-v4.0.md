# MEDICAL SPACE v4.0

Production & Deployment build for the Medical Space educational platform.

This release preserves v3.5 functionality and adds deployment artifacts, backup/restore scripts, production environment templates, Nginx reverse-proxy configuration, systemd service configuration, Docker/Compose configuration, and a production smoke-test checklist.

**Status:** production-deployment ready package; public deployment itself still requires a real domain, server, DNS, HTTPS certificate, secrets, and operator configuration.
