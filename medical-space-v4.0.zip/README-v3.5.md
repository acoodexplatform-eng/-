# Medical Space v3.5

Security-hardening release following v3.4 SEO/performance work.

See `SECURITY-AUDIT-v3.5.md` for the implemented controls and remaining production requirements.
