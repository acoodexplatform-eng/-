#!/usr/bin/env python3
"""MEDICAL SPACE local prototype backend. Python 3.10+, no third-party dependencies."""
import base64, gzip, hashlib, hmac, json, os, re, secrets, sqlite3, time, io, shutil, sys, mimetypes
from collections import defaultdict
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from email.parser import BytesParser
from email.policy import default as email_policy
from urllib.parse import urlparse, quote

ROOT=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('MEDICAL_SPACE_DATA',str(ROOT/'server'/'private'))).resolve()
DB=DATA/'medical_space.sqlite3'
MEDIA=DATA/'media'
SECRET_PATH=DATA/'session.key'
HOST=os.environ.get('HOST','127.0.0.1'); PORT=int(os.environ.get('PORT','8000'))
MAX_BODY=16_384
MAX_UPLOAD=60*1024*1024
ALLOWED_UPLOADS={
    'video/mp4','video/webm','video/ogg','audio/mpeg','audio/mp4','audio/ogg','audio/wav','audio/webm',
    'application/pdf','image/jpeg','image/png','image/webp','image/gif'
}
LOGIN_ATTEMPTS=defaultdict(list)
REGISTER_ATTEMPTS=defaultdict(list)
MUTATION_ATTEMPTS=defaultdict(list)
MAX_REQUESTS_PER_WINDOW=30
RATE_WINDOW=900
MAX_MUTATIONS_PER_WINDOW=120
COURSES=json.loads((ROOT/'assets/data/courses.json').read_text(encoding='utf8'))

def db_courses(con):
    rows=con.execute('SELECT id,title_ar,title_en,description_ar,description_en,icon,pricing_kind,category,program_type,instructor,lecture_count,duration,study_method,attendance,certificate,status FROM courses ORDER BY rowid').fetchall()
    out=[]
    for r in rows:
        course=dict(r); mods=[]
        for m in con.execute('SELECT id,title_ar,title_en,sort_order FROM modules WHERE course_id=? ORDER BY sort_order,id',(r['id'],)):
            lessons=[]
            for l in con.execute('SELECT id,title_ar,title_en,type,duration_min,description_ar,description_en,resource_url,sort_order,media_id FROM lessons WHERE module_id=? ORDER BY sort_order,id',(m['id'],)):
                lessons.append(dict(l))
            mods.append({'id':m['id'],'title_ar':m['title_ar'],'title_en':m['title_en'],'lessons':lessons})
        course['pricing_example']=course.pop('pricing_kind'); course['modules']=mods; out.append(course)
    return out

def course_ids(con): return {r['id'] for r in con.execute('SELECT id FROM courses')}


def db():
    con=sqlite3.connect(DB,timeout=10); con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON'); return con

def init():
    DATA.mkdir(parents=True,exist_ok=True)
    try: os.chmod(DATA,0o700)
    except OSError: pass
    if not SECRET_PATH.exists():
        fd=os.open(SECRET_PATH,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as f: f.write(secrets.token_bytes(32))
    with db() as c:
        c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, salt TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,csrf TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS enrollments(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,course_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('active','pending')),created_at INTEGER NOT NULL,PRIMARY KEY(user_id,course_id));
CREATE TABLE IF NOT EXISTS lesson_progress(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,course_id TEXT NOT NULL,lesson_id TEXT NOT NULL,completed_at INTEGER NOT NULL,PRIMARY KEY(user_id,lesson_id));
CREATE TABLE IF NOT EXISTS course_settings(course_id TEXT PRIMARY KEY,published INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS quizzes(id INTEGER PRIMARY KEY,course_id TEXT NOT NULL UNIQUE,title_ar TEXT NOT NULL,title_en TEXT NOT NULL,published INTEGER NOT NULL DEFAULT 0,pass_percent INTEGER NOT NULL DEFAULT 70,duration_min INTEGER NOT NULL DEFAULT 30,max_attempts INTEGER NOT NULL DEFAULT 0,show_answers INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY,quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,prompt TEXT NOT NULL,options_json TEXT NOT NULL,correct_index INTEGER NOT NULL,explanation TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY,quiz_id INTEGER NOT NULL REFERENCES quizzes(id),user_id INTEGER NOT NULL REFERENCES users(id),score INTEGER NOT NULL,total INTEGER NOT NULL,percent INTEGER NOT NULL DEFAULT 0,passed INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS certificates(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),course_id TEXT NOT NULL,attempt_id INTEGER REFERENCES attempts(id),issued_at INTEGER NOT NULL,UNIQUE(user_id,course_id));
CREATE TABLE IF NOT EXISTS course_pricing(course_id TEXT PRIMARY KEY,amount INTEGER NOT NULL DEFAULT 0,currency TEXT NOT NULL DEFAULT 'SDG',payment_instructions TEXT NOT NULL DEFAULT 'تواصل مع الإدارة عبر واتساب لإتمام الدفع.',updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payment_requests(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),course_id TEXT NOT NULL,amount INTEGER NOT NULL,currency TEXT NOT NULL,method TEXT NOT NULL,reference TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected')),created_at INTEGER NOT NULL,reviewed_at INTEGER);
CREATE TABLE IF NOT EXISTS courses(id TEXT PRIMARY KEY,title_ar TEXT NOT NULL,title_en TEXT NOT NULL,description_ar TEXT NOT NULL,description_en TEXT NOT NULL,icon TEXT NOT NULL DEFAULT '⚕',pricing_kind TEXT NOT NULL DEFAULT 'free',category TEXT NOT NULL DEFAULT 'الطب والعلوم الطبية',program_type TEXT NOT NULL DEFAULT 'course',instructor TEXT NOT NULL DEFAULT '',lecture_count INTEGER NOT NULL DEFAULT 0,duration TEXT NOT NULL DEFAULT '',study_method TEXT NOT NULL DEFAULT '',attendance TEXT NOT NULL DEFAULT 'غير محدد',certificate TEXT NOT NULL DEFAULT 'غير محددة',status TEXT NOT NULL DEFAULT 'available');
CREATE TABLE IF NOT EXISTS modules(id TEXT PRIMARY KEY,course_id TEXT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,title_ar TEXT NOT NULL,title_en TEXT NOT NULL,sort_order INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS lessons(id TEXT PRIMARY KEY,module_id TEXT NOT NULL REFERENCES modules(id) ON DELETE CASCADE,title_ar TEXT NOT NULL,title_en TEXT NOT NULL,type TEXT NOT NULL,duration_min INTEGER NOT NULL DEFAULT 1,description_ar TEXT NOT NULL DEFAULT '',description_en TEXT NOT NULL DEFAULT '',resource_url TEXT NOT NULL DEFAULT '',sort_order INTEGER NOT NULL DEFAULT 0,media_id TEXT);
CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,lesson_id TEXT REFERENCES lessons(id) ON DELETE SET NULL,original_name TEXT NOT NULL,stored_name TEXT NOT NULL UNIQUE,mime TEXT NOT NULL,size INTEGER NOT NULL,uploaded_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,title_ar TEXT NOT NULL,title_en TEXT NOT NULL,message_ar TEXT NOT NULL,message_en TEXT NOT NULL,type TEXT NOT NULL DEFAULT 'info',link TEXT NOT NULL DEFAULT '',is_read INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL);""")
        c.execute("DELETE FROM sessions WHERE expires<=?", (int(time.time()),))
        c.execute("CREATE TABLE IF NOT EXISTS medical_fields(id TEXT PRIMARY KEY,name_ar TEXT NOT NULL,name_en TEXT NOT NULL,description_ar TEXT NOT NULL DEFAULT '',description_en TEXT NOT NULL DEFAULT '',icon TEXT NOT NULL DEFAULT '✚',sort_order INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1)")
        c.execute("CREATE TABLE IF NOT EXISTS course_fields(course_id TEXT PRIMARY KEY REFERENCES courses(id) ON DELETE CASCADE,field_id TEXT NOT NULL REFERENCES medical_fields(id) ON DELETE RESTRICT)")
        if not c.execute('SELECT 1 FROM medical_fields LIMIT 1').fetchone():
            seed_fields=[
              ('clinical','الطب والعلوم السريرية','Clinical Medicine & Medical Sciences','المعارف الطبية الأساسية والموضوعات السريرية العامة.','Foundational medical knowledge and general clinical topics.','✚',1),
              ('public-health','الصحة العامة والإدارة الصحية','Public Health & Healthcare Management','الإدارة الصحية والصحة العامة والوقاية والتثقيف الصحي.','Healthcare management, public health, prevention, and health education.','♧',2),
              ('nursing','التمريض','Nursing','مسارات التمريض العام والتخصصات والرعاية الحرجة والطوارئ.','General nursing, specialty nursing, critical care, and emergency care.','♿',3),
              ('laboratory','المختبرات والعلوم الطبية','Medical Laboratory & Biomedical Sciences','المختبرات الطبية والدم والطفيليات والأحياء الدقيقة والفحوصات.','Medical laboratory science, hematology, parasitology, microbiology, and diagnostics.','🔬',4),
              ('veterinary','الطب البيطري','Veterinary Medicine','الطب البيطري والطب المخبري البيطري.','Companion animal medicine and veterinary laboratory science.','🐾',5),
              ('dentistry','طب الأسنان','Dentistry','الخلع، مساعد طب الأسنان، الطوارئ، مكافحة العدوى والأشعة.','Extraction, dental assisting, emergencies, infection control, and radiology.','🦷',6),
              ('pharmacy-cosmetic','الصيدلة والتجميل','Pharmacy & Cosmetic Formulation','سلامة الأدوية، الأدوية المزمنة، أدوية OTC والتراكيب والتجميل.','Medication safety, chronic medicines, OTC drugs, formulations, and cosmetic care.','⚗',7)
            ]
            c.executemany('INSERT INTO medical_fields(id,name_ar,name_en,description_ar,description_en,icon,sort_order) VALUES(?,?,?,?,?,?,?)',seed_fields)
            mapping={
              'clinical':['medical-terminology','pathology','urinary-tract-infections','tropical-medicine-hygiene'],
              'public-health':['healthcare-management'],
              'nursing':['oncology-nursing','critical-care-nursing','operating-room-nursing','pediatric-nursing','geriatric-nursing','hemodialysis','basics-of-nursing','first-aid'],
              'laboratory':['basic-microbiology','malaria-microscopy-basics','stool-examination','cbc-workshop','blood-transfusion','leukemia','medical-laboratory','mycology','basic-parasitology'],
              'veterinary':['companion-animal-medicine','veterinary-medical-laboratory'],
              'dentistry':['tooth-extraction','dental-assistant','dental-clinic-first-aid','dental-infection-control','dental-radiology'],
              'pharmacy-cosmetic':['cosmetic-formulation','chemical-peeling','medication-safety','chronic-disease-medications','otc-drugs']
            }
            for fid,ids in mapping.items():
                for cid in ids:
                    if c.execute('SELECT 1 FROM courses WHERE id=?',(cid,)).fetchone(): c.execute('INSERT OR IGNORE INTO course_fields(course_id,field_id) VALUES(?,?)',(cid,fid))
        c.execute('DELETE FROM sessions WHERE expires <= ?', (int(time.time()),))
        lcols=[r[1] for r in c.execute('PRAGMA table_info(lessons)')]
        if 'media_id' not in lcols: c.execute('ALTER TABLE lessons ADD COLUMN media_id TEXT')
        MEDIA.mkdir(parents=True,exist_ok=True)
        # v2.2: migrate the original JSON curriculum into editable database content.
        if not c.execute('SELECT 1 FROM courses LIMIT 1').fetchone():
            for course in COURSES:
                c.execute('INSERT INTO courses(id,title_ar,title_en,description_ar,description_en,icon,pricing_kind,category,program_type,instructor,lecture_count,duration,study_method,attendance,certificate,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(course['id'],course['title_ar'],course['title_en'],course['description_ar'],course['description_en'],course.get('icon','⚕'),course.get('pricing_example','free'),course.get('category','الطب والعلوم الطبية'),course.get('program_type','course'),course.get('instructor',''),int(course.get('lecture_count',0)),course.get('duration',''),course.get('study_method',''),course.get('attendance','غير محدد'),course.get('certificate','غير محددة'),course.get('status','available')))
                for mi,m in enumerate(course.get('modules',[])):
                    c.execute('INSERT INTO modules(id,course_id,title_ar,title_en,sort_order) VALUES(?,?,?,?,?)',(m['id'],course['id'],m['title_ar'],m['title_en'],mi))
                    for li,l in enumerate(m.get('lessons',[])):
                        c.execute('INSERT INTO lessons(id,module_id,title_ar,title_en,type,duration_min,description_ar,description_en,resource_url,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)',(l['id'],m['id'],l['title_ar'],l['title_en'],l.get('type','video'),int(l.get('duration_min',1)),l.get('description_ar',''),l.get('description_en',''),l.get('resource_url',''),li))

        # v2.8: ensure every official catalog course is assigned to a medical field.
        field_mapping={
          'clinical':['medical-terminology','pathology','urinary-tract-infections','tropical-medicine-hygiene'],
          'public-health':['healthcare-management'],
          'nursing':['oncology-nursing','critical-care-nursing','operating-room-nursing','pediatric-nursing','geriatric-nursing','hemodialysis','basics-of-nursing','first-aid'],
          'laboratory':['basic-microbiology','malaria-microscopy-basics','stool-examination','cbc-workshop','blood-transfusion','leukemia','medical-laboratory','mycology','basic-parasitology'],
          'veterinary':['companion-animal-medicine','veterinary-medical-laboratory'],
          'dentistry':['tooth-extraction','dental-assistant','dental-clinic-first-aid','dental-infection-control','dental-radiology'],
          'pharmacy-cosmetic':['cosmetic-formulation','chemical-peeling','medication-safety','chronic-disease-medications','otc-drugs']
        }
        for fid,ids in field_mapping.items():
            for cid in ids:
                if c.execute('SELECT 1 FROM courses WHERE id=?',(cid,)).fetchone(): c.execute('INSERT OR IGNORE INTO course_fields(course_id,field_id) VALUES(?,?)',(cid,fid))

        # v2.5 catalog metadata migrations.
        course_cols=[r[1] for r in c.execute('PRAGMA table_info(courses)')]
        for name,ddl in [('category',"TEXT NOT NULL DEFAULT 'الطب والعلوم الطبية'"),('program_type',"TEXT NOT NULL DEFAULT 'course'"),('instructor',"TEXT NOT NULL DEFAULT ''"),('lecture_count','INTEGER NOT NULL DEFAULT 0'),('duration',"TEXT NOT NULL DEFAULT ''"),('study_method',"TEXT NOT NULL DEFAULT ''"),('attendance',"TEXT NOT NULL DEFAULT 'غير محدد'"),('certificate',"TEXT NOT NULL DEFAULT 'غير محددة'"),('status',"TEXT NOT NULL DEFAULT 'available'")]:
            if name not in course_cols: c.execute(f'ALTER TABLE courses ADD COLUMN {name} {ddl}')
        # Synchronize the official catalog metadata without overwriting admin-authored lesson content.
        for course in COURSES:
            c.execute("UPDATE courses SET title_ar=?,title_en=?,description_ar=?,description_en=?,category=?,program_type=?,instructor=?,lecture_count=?,duration=?,study_method=?,attendance=?,certificate=?,status=? WHERE id=?",(course['title_ar'],course['title_en'],course['description_ar'],course['description_en'],course.get('category','الطب والعلوم الطبية'),course.get('program_type','course'),course.get('instructor',''),int(course.get('lecture_count',0)),course.get('duration',''),course.get('study_method',''),course.get('attendance','غير محدد'),course.get('certificate','غير محددة'),course.get('status','available'),course['id']))

        # Lightweight migrations for v1.9 exam settings/results.
        qcols=[r[1] for r in c.execute('PRAGMA table_info(quizzes)')]
        for name,ddl in [('pass_percent','INTEGER NOT NULL DEFAULT 70'),('duration_min','INTEGER NOT NULL DEFAULT 30'),('max_attempts','INTEGER NOT NULL DEFAULT 0'),('show_answers','INTEGER NOT NULL DEFAULT 1')]:
            if name not in qcols:c.execute(f'ALTER TABLE quizzes ADD COLUMN {name} {ddl}')
        qc=[r[1] for r in c.execute('PRAGMA table_info(questions)')]
        if 'explanation' not in qc:c.execute("ALTER TABLE questions ADD COLUMN explanation TEXT NOT NULL DEFAULT ''")
        ac=[r[1] for r in c.execute('PRAGMA table_info(attempts)')]
        for name,ddl in [('percent','INTEGER NOT NULL DEFAULT 0'),('passed','INTEGER NOT NULL DEFAULT 0')]:
            if name not in ac:c.execute(f'ALTER TABLE attempts ADD COLUMN {name} {ddl}')
        cols=[r[1] for r in c.execute('PRAGMA table_info(users)')]
        if 'is_admin' not in cols:c.execute('ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0')
        for course in COURSES:
            if not c.execute('SELECT 1 FROM courses WHERE id=?',(course['id'],)).fetchone():
                c.execute('INSERT INTO courses(id,title_ar,title_en,description_ar,description_en,icon,pricing_kind,category,program_type,instructor,lecture_count,duration,study_method,attendance,certificate,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(course['id'],course['title_ar'],course['title_en'],course['description_ar'],course['description_en'],course.get('icon','⚕'),course.get('pricing_example','free'),course.get('category','الطب والعلوم الطبية'),course.get('program_type','course'),course.get('instructor',''),int(course.get('lecture_count',0)),course.get('duration',''),course.get('study_method',''),course.get('attendance','غير محدد'),course.get('certificate','غير محددة'),course.get('status','available')))
                for mi,m in enumerate(course.get('modules',[])):
                    c.execute('INSERT OR IGNORE INTO modules(id,course_id,title_ar,title_en,sort_order) VALUES(?,?,?,?,?)',(m['id'],course['id'],m['title_ar'],m['title_en'],mi))
                    for li,l in enumerate(m.get('lessons',[])):
                        c.execute('INSERT OR IGNORE INTO lessons(id,module_id,title_ar,title_en,type,duration_min,description_ar,description_en,resource_url,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?)',(l['id'],m['id'],l['title_ar'],l['title_en'],l.get('type','text'),int(l.get('duration_min',1)),l.get('description_ar',''),l.get('description_en',''),l.get('resource_url',''),li))
            c.execute('INSERT OR IGNORE INTO course_settings(course_id,published) VALUES(?,1)',(course['id'],))
            c.execute("INSERT OR IGNORE INTO course_pricing(course_id,amount,currency,payment_instructions,updated_at) VALUES(?,?,?,?,?)",(course['id'],0,'SDG','تواصل مع الإدارة عبر واتساب لإتمام الدفع.',int(time.time())))

def notify_user(con,user_id,title_ar,title_en,message_ar,message_en,kind='info',link=''):
    con.execute('INSERT INTO notifications(user_id,title_ar,title_en,message_ar,message_en,type,link,is_read,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(user_id,title_ar,title_en,message_ar,message_en,kind,link,0,int(time.time())))

def notify_all_students(con,title_ar,title_en,message_ar,message_en,kind='announcement',link=''):
    for r in con.execute('SELECT id FROM users WHERE is_admin=0'):
        notify_user(con,r['id'],title_ar,title_en,message_ar,message_en,kind,link)

def hash_pw(password,salt): return hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
def secret(): return SECRET_PATH.read_bytes()
def sign(token): return hmac.new(secret(),token.encode(),'sha256').hexdigest()

def session_from(handler):
    cookie=SimpleCookie()
    try: cookie.load(handler.headers.get('Cookie',''))
    except Exception: return None
    morsel=cookie.get('ms_session')
    if not morsel: return None
    token=morsel.value
    if not re.fullmatch('[a-f0-9]{64}',token): return None
    with db() as c:
        row=c.execute('SELECT s.csrf,s.expires,u.id,u.name,u.email,u.is_admin FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?',(sign(token),)).fetchone()
    return dict(row) if row and row['expires']>time.time() else None

def public_base(handler):
    configured=os.environ.get('PUBLIC_BASE_URL','').strip().rstrip('/')
    if configured:
        return configured
    forwarded=(handler.headers.get('X-Forwarded-Proto','') or '').split(',')[0].strip().lower()
    scheme=forwarded if forwarded in ('http','https') else ('https' if os.environ.get('COOKIE_SECURE')=='1' else 'http')
    host=(handler.headers.get('Host','127.0.0.1:8000') or '127.0.0.1:8000').split(',',1)[0].strip()
    return f'{scheme}://{host}'

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def end_headers(self):
        path=urlparse(self.path).path
        if path in ('/robots.txt','/sitemap.xml'):
            self.send_header('Cache-Control','public, max-age=3600, must-revalidate')
        elif path.startswith('/api/') or path.startswith('/media/'):
            pass
        else:
            ext=Path(path).suffix.lower()
            if ext in {'.css','.js','.jpg','.jpeg','.png','.webp','.gif','.ico','.svg','.woff','.woff2'}:
                self.send_header('Cache-Control','public, max-age=31536000, immutable')
            elif ext in {'.html','.xml','.txt','.json'} or path=='/':
                self.send_header('Cache-Control','public, max-age=3600, must-revalidate')
        if os.environ.get('COOKIE_SECURE')=='1': self.send_header('Strict-Transport-Security','max-age=31536000; includeSubDomains')
        if path.startswith('/api/') or path.startswith('/media/'):
            self.send_header('X-Robots-Tag','noindex, nofollow, noarchive')
        self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','strict-origin-when-cross-origin');self.send_header('X-Frame-Options','DENY');self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()');self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('X-Permitted-Cross-Domain-Policies','none');self.send_header('Cross-Origin-Resource-Policy','same-origin');super().end_headers()
    def send_head(self):
        """Serve small text assets gzip-compressed when the browser supports it."""
        path=urlparse(self.path).path or '/'
        full=Path(self.translate_path(path))
        if full.is_dir():
            full=full/'index.html'
        compressible={'.html','.css','.js','.json','.xml','.txt','.svg'}
        accepts='gzip' in (self.headers.get('Accept-Encoding','') or '').lower()
        try:
            is_file=full.is_file() and full.resolve().is_relative_to(ROOT.resolve())
        except AttributeError:
            try: is_file=full.is_file() and str(full.resolve()).startswith(str(ROOT.resolve()))
            except Exception: is_file=False
        if is_file and full.suffix.lower() in compressible and accepts and full.stat().st_size <= 1024*1024:
            raw=full.read_bytes()
            gz=gzip.compress(raw,compresslevel=6,mtime=0)
            if len(gz)+32 < len(raw):
                self.send_response(HTTPStatus.OK)
                self.send_header('Content-Type',self.guess_type(str(full)))
                self.send_header('Content-Encoding','gzip')
                self.send_header('Vary','Accept-Encoding')
                self.send_header('Content-Length',str(len(gz)))
                self.send_header('Last-Modified',self.date_time_string(full.stat().st_mtime))
                self.end_headers()
                return io.BytesIO(gz)
        return super().send_head()

    def json(self,status,payload,cookie=None):
        raw=json.dumps(payload,ensure_ascii=False).encode()
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(raw)))
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers();self.wfile.write(raw)
    def do_GET(self):
        path=urlparse(self.path).path
        if path.startswith('/server/') or '/.' in path or path.startswith('/assets/data/') or path.startswith('/tests/') or path.startswith('/backups/'):
            self.send_error(404);return
        if path.startswith('/media/'):
            self.serve_media(path.rsplit('/',1)[-1])
            return
        if path=='/robots.txt':
            body=(f"User-agent: *\nAllow: /\nDisallow: /server/\nDisallow: /assets/data/\nDisallow: /tests/\nDisallow: /backups/\nDisallow: /admin.html\nDisallow: /dashboard.html\nDisallow: /login.html\nDisallow: /register.html\nDisallow: /payment.html\nDisallow: /quiz.html\nDisallow: /change-password.html\nSitemap: {public_base(self)}/sitemap.xml\n").encode('utf8')
            self.send_response(200);self.send_header('Content-Type','text/plain; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
        if path=='/sitemap.xml':
            base=public_base(self)
            with db() as c:
                ids=[r['id'] for r in c.execute('SELECT c.id FROM courses c JOIN course_settings s ON s.course_id=c.id WHERE s.published=1 ORDER BY c.rowid')]
            urls=['/','/about.html','/courses.html','/workshops.html','/trainers.html','/contact.html']+[f'/course.html?id={quote(cid,safe="")}' for cid in ids]
            xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{base}{u}</loc></url>' for u in urls)+'</urlset>\n'
            body=xml.encode('utf8');self.send_response(200);self.send_header('Content-Type','application/xml; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
        if path=='/api/health':
            self.json(200,{'ok':True,'service':'medical-space','version':'4.0','security':'hardened','production_ready':True});return
        if path=='/api/me':
            s=session_from(self);self.json(200,{'authenticated':bool(s),'user':{'id':s['id'],'name':s['name'],'email':s['email'],'is_admin':bool(s['is_admin'])} if s else None,'csrf':s['csrf'] if s else None});return
        if path=='/api/notifications':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            with db() as c:
                rows=[dict(r) for r in c.execute('SELECT id,title_ar,title_en,message_ar,message_en,type,link,is_read,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100',(s['id'],))]
                unread=c.execute('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND is_read=0',(s['id'],)).fetchone()['n']
            self.json(200,{'notifications':rows,'unread':unread});return
        if path=='/api/profile':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            self.json(200,{'name':s['name'],'email':s['email'],'is_admin':bool(s['is_admin'])});return
        if path=='/api/medical-fields':
            with db() as c:
                fields=[dict(r) for r in c.execute('SELECT id,name_ar,name_en,description_ar,description_en,icon,sort_order,active FROM medical_fields WHERE active=1 ORDER BY sort_order,id')]
                for f in fields:
                    f['courses']=[r['course_id'] for r in c.execute('SELECT course_id FROM course_fields WHERE field_id=? ORDER BY course_id',(f['id'],))]
            self.json(200,{'fields':fields});return
        if path=='/api/courses':
            with db() as c:
                published={r['course_id'] for r in c.execute('SELECT course_id FROM course_settings WHERE published=1')}
                prices={r['course_id']:dict(r) for r in c.execute('SELECT course_id,amount,currency,payment_instructions FROM course_pricing')}
                courses=db_courses(c)
            self.json(200,{'courses':[{'id':x['id'],'title_ar':x['title_ar'],'title_en':x['title_en'],'type':x['pricing_example'],'description_ar':x['description_ar'],'description_en':x['description_en'],'icon':x.get('icon','⚕'),'price_amount':prices.get(x['id'],{}).get('amount',0),'currency':prices.get(x['id'],{}).get('currency','SDG'),'payment_instructions':prices.get(x['id'],{}).get('payment_instructions',''),'modules_count':len(x.get('modules',[])),'lessons_count':sum(len(m.get('lessons',[])) for m in x.get('modules',[])),'category':x.get('category',''),'program_type':x.get('program_type','course'),'instructor':x.get('instructor',''),'lecture_count':x.get('lecture_count',0),'duration':x.get('duration',''),'study_method':x.get('study_method',''),'attendance':x.get('attendance','غير محدد'),'certificate':x.get('certificate','غير محددة'),'status':x.get('status','available')} for x in courses if x['id'] in published]});return
        if path.startswith('/api/course/'):
            cid=path.rsplit('/',1)[-1]
            with db() as c:
                course=next((x for x in db_courses(c) if x['id']==cid),None)
                pub=c.execute('SELECT published FROM course_settings WHERE course_id=?',(cid,)).fetchone()
                pricing=c.execute('SELECT amount,currency,payment_instructions FROM course_pricing WHERE course_id=?',(cid,)).fetchone()
            if not course or not pub or not pub['published']:self.json(404,{'error':'course_unavailable'});return
            s=session_from(self); enrolled=False; status=None; completed=[]
            if s:
                with db() as c:
                    e=c.execute('SELECT status FROM enrollments WHERE user_id=? AND course_id=?',(s['id'],cid)).fetchone()
                    enrolled=bool(e and e['status']=='active'); status=e['status'] if e else None
                    completed=[r['lesson_id'] for r in c.execute('SELECT lesson_id FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],cid))]
            modules=course.get('modules',[])
            flat=[l for m in modules for l in m.get('lessons',[])]
            completed_set=set(completed)
            unlocked=set()
            if enrolled:
                for i,l in enumerate(flat):
                    if i==0 or flat[i-1]['id'] in completed_set: unlocked.add(l['id'])
                for m in modules:
                    for l in m.get('lessons',[]):
                        l['completed']=l['id'] in completed_set
                        l['locked']=l['id'] not in unlocked and l['id'] not in completed_set
                        if l.get('media_id'): l['resource_url']='/media/'+l['media_id']
            else:
                for m in modules:
                    for l in m.get('lessons',[]): l['locked']=True; l['completed']=False
            total=len(flat); done=sum(1 for l in flat if l['id'] in completed_set)
            next_l=next((l for l in flat if l['id'] not in completed_set),None)
            self.json(200,{'course':{'id':course['id'],'title_ar':course['title_ar'],'title_en':course['title_en'],'description_ar':course['description_ar'],'description_en':course['description_en'],'type':course['pricing_example'],'icon':course.get('icon','⚕'),'category':course.get('category',''),'program_type':course.get('program_type','course'),'instructor':course.get('instructor',''),'lecture_count':course.get('lecture_count',0),'duration':course.get('duration',''),'study_method':course.get('study_method',''),'attendance':course.get('attendance','غير محدد'),'certificate':course.get('certificate','غير محددة'),'status':course.get('status','available'),'price_amount':pricing['amount'] if pricing else 0,'currency':pricing['currency'] if pricing else 'SDG','payment_instructions':pricing['payment_instructions'] if pricing else '','modules':modules},'access':{'authenticated':bool(s),'enrolled':enrolled,'status':status,'completed_lessons':completed,'completed_count':done,'total_lessons':total,'percent':round(done*100/total) if total else 0,'next_lesson_id':next_l['id'] if next_l else None,'all_lessons_complete':bool(total and done==total)}});return
        if path=='/api/student/overview':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            with db() as c:
                courses=db_courses(c)
                cmap={x['id']:x for x in courses}
                enroll_rows=c.execute('SELECT course_id,status,created_at FROM enrollments WHERE user_id=? ORDER BY created_at DESC',(s['id'],)).fetchall()
                out=[]
                for e in enroll_rows:
                    course=cmap.get(e['course_id'])
                    if not course: continue
                    total=c.execute('SELECT COUNT(*) n FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=?',(e['course_id'],)).fetchone()['n']
                    done=c.execute('SELECT COUNT(*) n FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],e['course_id'])).fetchone()['n']
                    next_row=c.execute("""SELECT l.id,l.title_ar,l.title_en FROM lessons l JOIN modules m ON m.id=l.module_id
                        WHERE m.course_id=? AND NOT EXISTS(SELECT 1 FROM lesson_progress p WHERE p.user_id=? AND p.lesson_id=l.id)
                        ORDER BY m.sort_order,l.sort_order,l.id LIMIT 1""",(e['course_id'],s['id'])).fetchone()
                    out.append({'course_id':e['course_id'],'status':e['status'],'created_at':e['created_at'],'title_ar':course['title_ar'],'title_en':course['title_en'],'icon':course.get('icon','⚕'),'category':course.get('category',''),'program_type':course.get('program_type','course'),'instructor':course.get('instructor',''),'percent':round(done*100/total) if total else 0,'completed_count':done,'total_lessons':total,'next_lesson':dict(next_row) if next_row else None})
                active_ids=[x['course_id'] for x in enroll_rows if x['status']=='active']
                cert_count=c.execute('SELECT COUNT(*) n FROM certificates WHERE user_id=?',(s['id'],)).fetchone()['n']
                attempt_count=c.execute('SELECT COUNT(*) n FROM attempts WHERE user_id=?',(s['id'],)).fetchone()['n']
                passed_count=c.execute('SELECT COUNT(*) n FROM attempts WHERE user_id=? AND passed=1',(s['id'],)).fetchone()['n']
                pending_payments=c.execute("SELECT COUNT(*) n FROM payment_requests WHERE user_id=? AND status='pending'",(s['id'],)).fetchone()['n']
            self.json(200,{'enrollments':out,'stats':{'enrolled':len(enroll_rows),'active':len(active_ids),'completed':sum(1 for x in out if x['percent']>=100 and x['total_lessons']>0),'certificates':cert_count,'attempts':attempt_count,'passed_attempts':passed_count,'pending_payments':pending_payments}});return
        if path=='/api/progress':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            cid=urlparse(self.path).query.split('course_id=',1)[-1] if 'course_id=' in urlparse(self.path).query else ''
            with db() as c: rows=c.execute('SELECT lesson_id,completed_at FROM lesson_progress WHERE user_id=? AND course_id=? ORDER BY completed_at',(s['id'],cid)).fetchall()
            self.json(200,{'progress':[dict(r) for r in rows]});return
        if path=='/api/enrollments':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            with db() as c:
                rows=c.execute('SELECT course_id,status,created_at FROM enrollments WHERE user_id=? ORDER BY created_at DESC',(s['id'],)).fetchall()
                payments=c.execute('SELECT id,course_id,amount,currency,method,reference,status,created_at,reviewed_at FROM payment_requests WHERE user_id=? ORDER BY created_at DESC',(s['id'],)).fetchall()
            self.json(200,{'enrollments':[dict(x) for x in rows],'payments':[dict(x) for x in payments]});return
        if path=='/api/admin/reports':
            s=session_from(self)
            if not s or not s['is_admin']:
                self.json(403,{'error':'admin_required'});return
            try:
                qs=parse_qs(urlparse(self.path).query)
                days=max(7,min(730,int((qs.get('days') or ['90'])[0])))
            except Exception: days=90
            since=int(time.time())-days*86400
            with db() as c:
                course_rows=c.execute("""
                    SELECT c.id,c.title_ar,c.title_en,c.category,c.instructor,
                           COUNT(DISTINCT CASE WHEN e.status='active' THEN e.user_id END) active_students,
                           COUNT(DISTINCT CASE WHEN a.passed=1 THEN a.user_id END) passed_students,
                           COUNT(a.id) attempts, ROUND(AVG(a.percent),1) avg_score,
                           COUNT(DISTINCT cert.id) certificates
                    FROM courses c
                    LEFT JOIN enrollments e ON e.course_id=c.id
                    LEFT JOIN quizzes q ON q.course_id=c.id
                    LEFT JOIN attempts a ON a.quiz_id=q.id
                    LEFT JOIN certificates cert ON cert.course_id=c.id
                    GROUP BY c.id ORDER BY active_students DESC,c.title_ar
                """).fetchall()
                course_out=[]
                for r in course_rows:
                    total_lessons=c.execute('SELECT COUNT(*) n FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=?',(r['id'],)).fetchone()['n']
                    completed_students=0
                    if total_lessons:
                        completed_students=c.execute("""SELECT COUNT(*) n FROM enrollments e
                            WHERE e.course_id=? AND e.status='active' AND
                            (SELECT COUNT(*) FROM lesson_progress lp WHERE lp.user_id=e.user_id AND lp.course_id=e.course_id) >= ?""",(r['id'],total_lessons)).fetchone()['n']
                    row=dict(r);row['total_lessons']=total_lessons;row['completed_students']=completed_students
                    row['completion_rate']=round(completed_students*100/r['active_students'],1) if r['active_students'] else 0
                    course_out.append(row)
                monthly=[]
                now=int(time.time())
                for i in range(days//30 + (1 if days%30 else 0)):
                    end=now-i*30*86400;start=max(since,end-30*86400)
                    monthly.append({'start':start,'end':end,
                        'students':c.execute('SELECT COUNT(*) n FROM users WHERE is_admin=0 AND created_at>=? AND created_at<?',(start,end)).fetchone()['n'],
                        'enrollments':c.execute("SELECT COUNT(*) n FROM enrollments WHERE created_at>=? AND created_at<? AND status='active'",(start,end)).fetchone()['n'],
                        'approved_payments':c.execute("SELECT COUNT(*) n FROM payment_requests WHERE created_at>=? AND created_at<? AND status='approved'",(start,end)).fetchone()['n']})
                monthly.reverse()
                field_rows=c.execute("""SELECT f.id,f.name_ar,f.name_en,COUNT(DISTINCT e.user_id) students,
                    COUNT(DISTINCT cf.course_id) courses FROM medical_fields f
                    LEFT JOIN course_fields cf ON cf.field_id=f.id
                    LEFT JOIN enrollments e ON e.course_id=cf.course_id AND e.status='active'
                    WHERE f.active=1 GROUP BY f.id ORDER BY students DESC,f.sort_order""").fetchall()
                quiz_rows=c.execute("""SELECT q.id,q.title_ar,q.title_en,q.course_id,COUNT(a.id) attempts,
                    COUNT(CASE WHEN a.passed=1 THEN 1 END) passed,ROUND(AVG(a.percent),1) avg_score,MAX(a.percent) best_score
                    FROM quizzes q LEFT JOIN attempts a ON a.quiz_id=q.id GROUP BY q.id ORDER BY attempts DESC,q.title_ar""").fetchall()
                totals={'students':c.execute('SELECT COUNT(*) n FROM users WHERE is_admin=0').fetchone()['n'],
                    'new_students_period':c.execute('SELECT COUNT(*) n FROM users WHERE is_admin=0 AND created_at>=?',(since,)).fetchone()['n'],
                    'active_enrollments':c.execute("SELECT COUNT(*) n FROM enrollments WHERE status='active'").fetchone()['n'],
                    'completed_enrollments':c.execute("""SELECT COUNT(*) n FROM enrollments e WHERE e.status='active' AND
                        (SELECT COUNT(*) FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=e.course_id)>0 AND
                        (SELECT COUNT(*) FROM lesson_progress lp WHERE lp.user_id=e.user_id AND lp.course_id=e.course_id) >=
                        (SELECT COUNT(*) FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=e.course_id)""").fetchone()['n'],
                    'attempts':c.execute('SELECT COUNT(*) n FROM attempts').fetchone()['n'],
                    'passed_attempts':c.execute('SELECT COUNT(*) n FROM attempts WHERE passed=1').fetchone()['n'],
                    'certificates':c.execute('SELECT COUNT(*) n FROM certificates').fetchone()['n'],
                    'approved_payment_amount':c.execute("SELECT COALESCE(SUM(amount),0) n FROM payment_requests WHERE status='approved'").fetchone()['n'],
                    'pending_payment_amount':c.execute("SELECT COALESCE(SUM(amount),0) n FROM payment_requests WHERE status='pending'").fetchone()['n']}
            totals['pass_rate']=round(totals['passed_attempts']*100/totals['attempts'],1) if totals['attempts'] else 0
            totals['completion_rate']=round(totals['completed_enrollments']*100/totals['active_enrollments'],1) if totals['active_enrollments'] else 0
            self.json(200,{'period_days':days,'since':since,'totals':totals,'courses':[dict(x) for x in course_out],'monthly':monthly,'fields':[dict(x) for x in field_rows],'quizzes':[dict(x) for x in quiz_rows]});return
        if path=='/api/admin/reports.csv':
            s=session_from(self)
            if not s or not s['is_admin']:
                self.send_error(403);return
            try: days=max(7,min(730,int((parse_qs(urlparse(self.path).query).get('days') or ['90'])[0])))
            except Exception: days=90
            with db() as c:
                rows=c.execute("""SELECT c.title_ar,c.title_en,c.category,
                    COUNT(DISTINCT CASE WHEN e.status='active' THEN e.user_id END) active_students,
                    COUNT(DISTINCT cert.id) certificates,COUNT(a.id) attempts,
                    COUNT(CASE WHEN a.passed=1 THEN 1 END) passed_attempts,ROUND(AVG(a.percent),1) avg_score
                    FROM courses c LEFT JOIN enrollments e ON e.course_id=c.id LEFT JOIN quizzes q ON q.course_id=c.id
                    LEFT JOIN attempts a ON a.quiz_id=q.id LEFT JOIN certificates cert ON cert.course_id=c.id
                    GROUP BY c.id ORDER BY active_students DESC,c.title_ar""").fetchall()
            import csv
            buf=io.StringIO();w=csv.writer(buf);w.writerow(['Course AR','Course EN','Category','Active Students','Certificates','Attempts','Passed Attempts','Average Score'])
            for r in rows:w.writerow([r['title_ar'],r['title_en'],r['category'],r['active_students'],r['certificates'],r['attempts'],r['passed_attempts'],r['avg_score'] or 0])
            raw=buf.getvalue().encode('utf-8-sig');self.send_response(200);self.send_header('Content-Type','text/csv; charset=utf-8');self.send_header('Content-Disposition',f'attachment; filename="medical-space-report-{days}d.csv"');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path=='/api/admin/overview':
            s=session_from(self)
            if not s or not s['is_admin']:self.json(403,{'error':'admin_required'});return
            with db() as c:
                users=[dict(r) for r in c.execute('SELECT id,name,email,created_at FROM users ORDER BY id DESC LIMIT 200')]
                enrollments=[dict(r) for r in c.execute('SELECT e.user_id,u.name,u.email,e.course_id,e.status FROM enrollments e JOIN users u ON u.id=e.user_id ORDER BY e.created_at DESC LIMIT 300')]
                settings={r['course_id']:bool(r['published']) for r in c.execute('SELECT * FROM course_settings')}
                quizzes=[dict(r) for r in c.execute('SELECT id,course_id,title_ar,title_en,published,pass_percent,duration_min,max_attempts,show_answers FROM quizzes')]
                attempts=[dict(r) for r in c.execute('SELECT a.id,a.user_id,u.name,q.course_id,q.title_ar,a.score,a.total,a.percent,a.passed,a.created_at FROM attempts a JOIN users u ON u.id=a.user_id JOIN quizzes q ON q.id=a.quiz_id ORDER BY a.id DESC LIMIT 300')]
                certs=[dict(r) for r in c.execute('SELECT c.id,c.user_id,u.name,c.course_id,c.issued_at FROM certificates c JOIN users u ON u.id=c.user_id ORDER BY c.issued_at DESC LIMIT 200')]
                pricing=[dict(r) for r in c.execute('SELECT course_id,amount,currency,payment_instructions,updated_at FROM course_pricing ORDER BY course_id')]
                payments=[dict(r) for r in c.execute('SELECT p.id,p.user_id,u.name,u.email,p.course_id,p.amount,p.currency,p.method,p.reference,p.note,p.status,p.created_at,p.reviewed_at FROM payment_requests p JOIN users u ON u.id=p.user_id ORDER BY p.created_at DESC LIMIT 300')]
                courses=db_courses(c)
                modules=[dict(r) for r in c.execute('SELECT id,course_id,title_ar,title_en,sort_order FROM modules ORDER BY course_id,sort_order,id')]
                lessons=[dict(r) for r in c.execute('SELECT l.id,l.module_id,m.course_id,l.title_ar,l.title_en,l.type,l.duration_min,l.description_ar,l.description_en,l.resource_url,l.sort_order,l.media_id FROM lessons l JOIN modules m ON m.id=l.module_id ORDER BY m.course_id,m.sort_order,l.sort_order,l.id')]
                media=[dict(r) for r in c.execute('SELECT id,lesson_id,original_name,mime,size,uploaded_at FROM media ORDER BY uploaded_at DESC LIMIT 300')]
                fields=[dict(r) for r in c.execute('SELECT id,name_ar,name_en,description_ar,description_en,icon,sort_order,active FROM medical_fields ORDER BY sort_order,id')]
                course_fields=[dict(r) for r in c.execute('SELECT course_id,field_id FROM course_fields ORDER BY field_id,course_id')]
                stats={
                    'students': c.execute('SELECT COUNT(*) n FROM users WHERE is_admin=0').fetchone()['n'],
                    'admins': c.execute('SELECT COUNT(*) n FROM users WHERE is_admin=1').fetchone()['n'],
                    'courses': len(courses),
                    'published_courses': sum(1 for x in courses if settings.get(x['id'],False)),
                    'medical_fields': len(fields),
                    'modules': len(modules),
                    'lessons': len(lessons),
                    'enrollments': c.execute("SELECT COUNT(*) n FROM enrollments WHERE status='active'").fetchone()['n'],
                    'pending_enrollments': c.execute("SELECT COUNT(*) n FROM enrollments WHERE status='pending'").fetchone()['n'],
                    'pending_payments': c.execute("SELECT COUNT(*) n FROM payment_requests WHERE status='pending'").fetchone()['n'],
                    'quizzes': len(quizzes),
                    'attempts': len(attempts),
                    'certificates': len(certs),
                    'media': len(media),
                    'unread_notifications': c.execute('SELECT COUNT(*) n FROM notifications WHERE is_read=0').fetchone()['n']
                }
            self.json(200,{'users':users,'enrollments':enrollments,'courses':[{**x,'published':settings.get(x['id'],False)} for x in courses],'modules':modules,'lessons':lessons,'media':media,'quizzes':quizzes,'attempts':attempts,'certificates':certs,'pricing':pricing,'payments':payments,'medical_fields':fields,'course_fields':course_fields,'stats':stats});return
        if path=='/api/quizzes':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            with db() as c:
                rows=c.execute("SELECT q.id,q.course_id,q.title_ar,q.title_en,q.pass_percent,q.duration_min,q.max_attempts,q.show_answers,(SELECT COUNT(*) FROM attempts a WHERE a.quiz_id=q.id AND a.user_id=?) attempts_used FROM quizzes q JOIN enrollments e ON e.course_id=q.course_id WHERE e.user_id=? AND e.status='active' AND q.published=1",(s['id'],s['id'])).fetchall()
                out=[]
                for r in rows:
                    total=c.execute('SELECT COUNT(*) n FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=?',(r['course_id'],)).fetchone()['n']
                    done=c.execute('SELECT COUNT(*) n FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],r['course_id'])).fetchone()['n']
                    x=dict(r); x['ready']=bool(total and done>=total); x['completed_lessons']=done; x['total_lessons']=total; out.append(x)
            self.json(200,{'quizzes':out});return
        if path.startswith('/api/certificate/verify/'):
            certid=path.rsplit('/',1)[-1]
            if not re.fullmatch(r'[a-f0-9]{24}',certid):
                self.json(404,{'valid':False,'error':'not_found'});return
            with db() as c:
                cert=c.execute('SELECT c.id,c.course_id,c.issued_at,u.name,a.score,a.total,a.percent,a.passed FROM certificates c JOIN users u ON u.id=c.user_id LEFT JOIN attempts a ON a.id=c.attempt_id WHERE c.id=?',(certid,)).fetchone()
            if not cert:
                self.json(404,{'valid':False,'error':'certificate_not_found'});return
            with db() as c2: course=next((x for x in db_courses(c2) if x['id']==cert['course_id']),None)
            self.json(200,{'valid':True,'certificate':{'id':cert['id'],'student_name':cert['name'],'course_id':cert['course_id'],'course_title_ar':course['title_ar'] if course else cert['course_id'],'course_title_en':course['title_en'] if course else cert['course_id'],'issued_at':cert['issued_at'],'score':cert['score'],'total':cert['total'],'percent':cert['percent'],'passed':bool(cert['passed'])}});return
        if path.startswith('/api/certificate/pdf/'):
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            certid=path.rsplit('/',1)[-1]
            if not re.fullmatch(r'[a-f0-9]{24}',certid):self.json(404,{'error':'not_found'});return
            with db() as c:
                cert=c.execute('SELECT c.id,c.course_id,c.issued_at,u.name,a.score,a.total,a.percent,a.passed FROM certificates c JOIN users u ON u.id=c.user_id LEFT JOIN attempts a ON a.id=c.attempt_id WHERE c.id=? AND c.user_id=?',(certid,s['id'])).fetchone()
            if not cert:self.json(404,{'error':'not_found'});return
            try:
                from reportlab.pdfgen import canvas
                from reportlab.lib.colors import HexColor
                from reportlab.pdfbase import pdfmetrics
                from reportlab.pdfbase.ttfonts import TTFont
            except ImportError:self.json(503,{'error':'pdf_dependency_missing'});return
            with db() as c2: course=next((x for x in db_courses(c2) if x['id']==cert['course_id']),None)
            title_ar=course['title_ar'] if course else cert['course_id']; title_en=course['title_en'] if course else cert['course_id']
            buf=io.BytesIO();pdf=canvas.Canvas(buf,pagesize=(842,595));pdf.setTitle('MEDICAL SPACE Certificate '+certid)
            fontfile=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf');boldfile=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
            font='Helvetica';bold='Helvetica-Bold'
            if fontfile.exists():
                try: pdfmetrics.registerFont(TTFont('MSUnicode',str(fontfile)));font='MSUnicode'
                except Exception: pass
            if boldfile.exists():
                try: pdfmetrics.registerFont(TTFont('MSUnicodeBold',str(boldfile)));bold='MSUnicodeBold'
                except Exception: pass
            def rtl(text):
                try:
                    import arabic_reshaper
                    from bidi.algorithm import get_display
                    return get_display(arabic_reshaper.reshape(text))
                except ImportError:return text
            def centered(text,y,size=14,f=font,color='#ffffff'):
                pdf.setFillColor(HexColor(color));pdf.setFont(f,size);pdf.drawCentredString(421,y,text)
            pdf.setFillColor(HexColor('#061a33'));pdf.rect(0,0,842,595,fill=1,stroke=0)
            pdf.setStrokeColor(HexColor('#d8b878'));pdf.setLineWidth(3);pdf.rect(24,24,794,547,fill=0,stroke=1)
            pdf.setStrokeColor(HexColor('#5bbfe8'));pdf.setLineWidth(1);pdf.rect(34,34,774,527,fill=0,stroke=1)
            centered('MEDICAL SPACE',505,24,bold,'#7ed8ff')
            centered('ACCESS PLATFORM  |  MEDICAL EDUCATION',480,11,font,'#ffffff')
            centered('CERTIFICATE OF COMPLETION',415,30,bold,'#d8b878')
            centered('شهادة إتمام',380,18,bold,'#ffffff')
            centered('This certificate is awarded to',342,13,font,'#ffffff')
            name=cert['name']
            if any('\u0600'<=ch<='\u06ff' for ch in name): name=rtl(name)
            centered(name,305,25,bold,'#ffffff')
            centered('لإتمامه / إتمامها بنجاح',272,12,font,'#cfefff')
            centered(title_en[:75],238,15,bold,'#7ed8ff')
            centered(rtl(title_ar)[:75],210,13,font,'#ffffff')
            if cert['total']: centered(f"Assessment result: {cert['score']}/{cert['total']}  |  {cert['percent']}%",174,12,font,'#ffffff')
            issued=datetime.fromtimestamp(cert['issued_at'],timezone.utc).strftime('%Y-%m-%d')
            centered(f'Issued: {issued}',138,10,font,'#cfefff')
            centered('Certificate ID: '+certid,118,10,font,'#cfefff')
            centered('Verify: /certificate.html?id='+certid,96,9,font,'#7ed8ff')
            centered('Issued by MEDICAL SPACE administration',66,9,font,'#ffffff')
            pdf.showPage();pdf.save();raw=buf.getvalue()
            self.send_response(200);self.send_header('Content-Type','application/pdf');self.send_header('Content-Disposition',f'attachment; filename="medical-space-{certid}.pdf"');self.send_header('Cache-Control','private, no-store');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path=='/api/certificates':
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            with db() as c:rows=c.execute('SELECT id,course_id,issued_at FROM certificates WHERE user_id=?',(s['id'],)).fetchall()
            self.json(200,{'certificates':[dict(r) for r in rows]});return
        if path.startswith('/api/quiz/'):
            s=session_from(self)
            if not s:self.json(401,{'error':'login_required'});return
            try:qid=int(path.split('/')[-1])
            except ValueError:self.json(404,{'error':'not_found'});return
            with db() as c:
                q=c.execute("SELECT q.* FROM quizzes q JOIN enrollments e ON e.course_id=q.course_id WHERE q.id=? AND q.published=1 AND e.user_id=? AND e.status='active'",(qid,s['id'])).fetchone()
                questions=c.execute('SELECT id,prompt,options_json,explanation FROM questions WHERE quiz_id=? ORDER BY id',(qid,)).fetchall() if q else []
            if not q:self.json(404,{'error':'quiz_unavailable'});return
            with db() as c:
                total=c.execute('SELECT COUNT(*) n FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=?',(q['course_id'],)).fetchone()['n']
                done=c.execute('SELECT COUNT(*) n FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],q['course_id'])).fetchone()['n']
            if total and done<total:self.json(403,{'error':'lessons_incomplete','completed_lessons':done,'total_lessons':total});return
            
            with db() as c:
                used=c.execute('SELECT COUNT(*) n FROM attempts WHERE quiz_id=? AND user_id=?',(qid,s['id'])).fetchone()['n']
            if q['max_attempts'] and used>=q['max_attempts']:
                self.json(429,{'error':'max_attempts_reached','attempts_used':used,'max_attempts':q['max_attempts']});return
            self.json(200,{'id':qid,'title_ar':q['title_ar'],'title_en':q['title_en'],'pass_percent':q['pass_percent'],'duration_min':q['duration_min'],'max_attempts':q['max_attempts'],'attempts_used':used,'show_answers':bool(q['show_answers']),'questions':[{'id':r['id'],'prompt':r['prompt'],'options':json.loads(r['options_json'])} for r in questions]});return
        return super().do_GET()
    def serve_media(self, media_id):
        if not re.fullmatch(r'[a-f0-9]{24}',media_id): self.send_error(404); return
        s=session_from(self)
        if not s: self.send_error(401); return
        with db() as c:
            row=c.execute('SELECT m.*,l.module_id,mo.course_id FROM media m LEFT JOIN lessons l ON l.id=m.lesson_id LEFT JOIN modules mo ON mo.id=l.module_id WHERE m.id=?',(media_id,)).fetchone()
            if not row: self.send_error(404); return
            if not s['is_admin']:
                if not row['course_id']:
                    self.send_error(403); return
                e=c.execute("SELECT status FROM enrollments WHERE user_id=? AND course_id=?",(s['id'],row['course_id'])).fetchone()
                if not e or e['status']!='active': self.send_error(403); return
        fp=MEDIA/row['stored_name']
        if not fp.is_file(): self.send_error(404); return
        size=fp.stat().st_size; start=0; end=size-1
        rng=self.headers.get('Range','')
        if rng.startswith('bytes='):
            try:
                spec=rng[6:].split(',',1)[0]
                a,b=(spec.split('-',1)+[''])[:2]
                if a=='':
                    n=int(b); start=max(0,size-n)
                else:
                    start=int(a); end=int(b) if b else size-1
                if start<0 or start>=size or end<start: raise ValueError()
                end=min(end,size-1)
            except Exception:
                self.send_response(416); self.send_header('Content-Range',f'bytes */{size}'); self.end_headers(); return
        length=end-start+1
        self.send_response(206 if rng else 200)
        self.send_header('Content-Type',row['mime']); self.send_header('Content-Length',str(length)); self.send_header('Accept-Ranges','bytes'); self.send_header('Cache-Control','private, no-store')
        self.send_header('Content-Disposition', 'inline; filename="'+re.sub(r'["\\\r\n]','_',row['original_name'])+'"')
        if rng:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers()
        with open(fp,'rb') as f:
            f.seek(start); remaining=length
            while remaining:
                chunk=f.read(min(1024*1024,remaining))
                if not chunk: break
                self.wfile.write(chunk); remaining-=len(chunk)

    def handle_media_upload(self):
        s=session_from(self)
        if not s or not s['is_admin']: self.json(403,{'error':'admin_required'}); return
        ctype=self.headers.get('Content-Type','')
        if not ctype.startswith('multipart/form-data') or 'boundary=' not in ctype: self.json(400,{'error':'multipart_required'}); return
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: length=0
        if length<=0 or length>MAX_UPLOAD: self.json(413,{'error':'file_too_large'}); return
        body=self.rfile.read(length)
        try:
            msg=BytesParser(policy=email_policy).parsebytes((f'Content-Type: {ctype}\r\nMIME-Version: 1.0\r\n\r\n').encode()+body)
            csrf=''; lesson_id=''; filepart=None
            for part in msg.iter_parts():
                disp=part.get('Content-Disposition','')
                name=part.get_param('name',header='Content-Disposition')
                if name=='csrf': csrf=part.get_payload(decode=True).decode('utf-8','ignore')
                elif name=='lesson_id': lesson_id=part.get_payload(decode=True).decode('utf-8','ignore')
                elif name=='file' and part.get_filename(): filepart=part
            if not csrf or not hmac.compare_digest(csrf,s['csrf']): self.json(403,{'error':'csrf'}); return
            if not filepart: self.json(400,{'error':'file_required'}); return
            raw=filepart.get_payload(decode=True) or b''; name=os.path.basename(filepart.get_filename()).strip()[:180]
            mime=(filepart.get_content_type() or '').lower()
            if mime=='application/octet-stream': mime=mimetypes.guess_type(name)[0] or mime
            if mime not in ALLOWED_UPLOADS: self.json(400,{'error':'unsupported_file_type'}); return
            if not raw or len(raw)>MAX_UPLOAD: self.json(413,{'error':'file_too_large'}); return
            signatures={
                'application/pdf': lambda b: b.startswith(b'%PDF-'),
                'image/jpeg': lambda b: b.startswith(b'\xff\xd8\xff'),
                'image/png': lambda b: b.startswith(b'\x89PNG\r\n\x1a\n'),
                'image/gif': lambda b: b.startswith((b'GIF87a',b'GIF89a')),
                'image/webp': lambda b: len(b)>=12 and b[:4]==b'RIFF' and b[8:12]==b'WEBP',
                'audio/mpeg': lambda b: b.startswith((b'ID3',)) or (len(b)>=2 and b[0]==0xff and (b[1]&0xe0)==0xe0),
                'audio/ogg': lambda b: b.startswith(b'OggS'),
                'audio/wav': lambda b: len(b)>=12 and b[:4]==b'RIFF' and b[8:12]==b'WAVE',
                'audio/mp4': lambda b: b'ftyp' in b[:32],
                'video/mp4': lambda b: b'ftyp' in b[:32],
                'video/webm': lambda b: b.startswith(b'\x1a\x45\xdf\xa3'),
                'video/ogg': lambda b: b.startswith(b'OggS'),
                'audio/webm': lambda b: b.startswith(b'\x1a\x45\xdf\xa3'),
            }
            checker=signatures.get(mime)
            if checker and not checker(raw[:64]): self.json(400,{'error':'file_signature_mismatch'}); return
            if lesson_id and not re.fullmatch(r'[a-z0-9_-]{2,100}',lesson_id): self.json(400,{'error':'invalid_lesson'}); return
            mid=secrets.token_hex(12); ext=Path(name).suffix.lower()[:12]; stored=mid+ext
            MEDIA.mkdir(parents=True,exist_ok=True); (MEDIA/stored).write_bytes(raw)
            now=int(time.time())
            try:
                with db() as c:
                    if lesson_id and not c.execute('SELECT id FROM lessons WHERE id=?',(lesson_id,)).fetchone(): raise ValueError()
                    c.execute('INSERT INTO media(id,lesson_id,original_name,stored_name,mime,size,uploaded_at) VALUES(?,?,?,?,?,?,?)',(mid,lesson_id or None,name or 'media',stored,mime,len(raw),now))
                    if lesson_id: c.execute('UPDATE lessons SET media_id=? WHERE id=?',(mid,lesson_id))
            except Exception:
                try: (MEDIA/stored).unlink(missing_ok=True)
                except OSError: pass
                raise
            self.json(200,{'ok':True,'media':{'id':mid,'lesson_id':lesson_id or None,'original_name':name,'mime':mime,'size':len(raw),'url':'/media/'+mid}})
        except ValueError: self.json(400,{'error':'invalid_upload'})
        except Exception: self.json(500,{'error':'upload_failed'})

    def do_POST(self):
        path=urlparse(self.path).path
        if path=='/api/admin/media-upload':
            self.handle_media_upload()
            return
        if path not in ('/api/register','/api/login','/api/logout','/api/change-password','/api/profile','/api/enroll','/api/progress/complete','/api/admin/course','/api/admin/course-delete','/api/admin/medical-field','/api/admin/medical-field-delete','/api/admin/module','/api/admin/module-delete','/api/admin/lesson','/api/admin/lesson-delete','/api/admin/media-upload','/api/admin/media-delete','/api/admin/enrollment','/api/admin/quiz','/api/admin/question','/api/admin/question-delete','/api/admin/certificate','/api/admin/pricing','/api/admin/payment','/api/payment/request','/api/quiz/submit','/api/notifications/read','/api/admin/notify'):
            self.json(404,{'error':'not_found'});return
        # JSON-only POST plus same-origin check. CSRF token required for authenticated mutations.
        ip=self.client_address[0]
        now=time.monotonic()
        MUTATION_ATTEMPTS[ip]=[t for t in MUTATION_ATTEMPTS[ip] if now-t<RATE_WINDOW]
        if path not in ('/api/login','/api/register') and len(MUTATION_ATTEMPTS[ip])>=MAX_MUTATIONS_PER_WINDOW:
            self.json(429,{'error':'too_many_requests'});return
        if path not in ('/api/login','/api/register'):
            MUTATION_ATTEMPTS[ip].append(now)
        origin=self.headers.get('Origin'); host=self.headers.get('Host','')
        if origin and urlparse(origin).netloc!=host:self.json(403,{'error':'origin_mismatch'});return
        if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':self.json(415,{'error':'json_required'});return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=MAX_BODY:raise ValueError()
            data=json.loads(self.rfile.read(length))
            if not isinstance(data,dict):raise ValueError()
        except (ValueError,TypeError,UnicodeError):self.json(400,{'error':'invalid_request'});return
        if path=='/api/register':
            ip=self.client_address[0]; now=time.monotonic(); REGISTER_ATTEMPTS[ip]=[t for t in REGISTER_ATTEMPTS[ip] if now-t<RATE_WINDOW]
            if len(REGISTER_ATTEMPTS[ip])>=MAX_REQUESTS_PER_WINDOW:self.json(429,{'error':'too_many_requests'});return
            REGISTER_ATTEMPTS[ip].append(now)
            name=str(data.get('name','')).strip();email=str(data.get('email','')).strip().lower();pw=data.get('password','')
            if not (2<=len(name)<=100 and re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) and len(email)<=254 and isinstance(pw,str) and 10<=len(pw)<=128):self.json(400,{'error':'invalid_fields'});return
            salt=secrets.token_hex(16)
            try:
                with db() as c:
                    cur=c.execute('INSERT INTO users(name,email,password_hash,salt,created_at) VALUES(?,?,?,?,?)',(name,email,hash_pw(pw,salt),salt,int(time.time())))
                    notify_user(c,cur.lastrowid,'مرحبًا بك في المساحة الطبية','Welcome to Medical Space','تم إنشاء حسابك بنجاح. نتمنى لك تجربة تعليمية مميزة.','Your account was created successfully. Welcome to your learning journey.','info','dashboard.html')
            except sqlite3.IntegrityError:self.json(409,{'error':'email_exists'});return
            self.json(201,{'ok':True});return
        if path=='/api/login':
            ip=self.client_address[0]; now=time.monotonic();LOGIN_ATTEMPTS[ip]=[t for t in LOGIN_ATTEMPTS[ip] if now-t<900]
            if len(LOGIN_ATTEMPTS[ip])>=10:self.json(429,{'error':'too_many_attempts'});return
            LOGIN_ATTEMPTS[ip].append(now)
            email=str(data.get('email','')).strip().lower();pw=data.get('password','')
            if not isinstance(pw,str) or len(pw)>128:self.json(400,{'error':'invalid_fields'});return
            with db() as c: row=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
            # Work factor even for nonexistent users; generic failure avoids account enumeration.
            if not row:
                hash_pw(pw,secrets.token_hex(16));self.json(401,{'error':'invalid_credentials'});return
            if not hmac.compare_digest(hash_pw(pw,row['salt']),row['password_hash']):self.json(401,{'error':'invalid_credentials'});return
            token=secrets.token_hex(32);csrf=secrets.token_hex(24)
            with db() as c:c.execute('INSERT INTO sessions(token_hash,user_id,csrf,expires) VALUES(?,?,?,?)',(sign(token),row['id'],csrf,int(time.time())+7*86400))
            LOGIN_ATTEMPTS.pop(ip,None)
            cookie=f'ms_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800'+('; Secure' if os.environ.get('COOKIE_SECURE')=='1' else '')
            self.json(200,{'ok':True},cookie);return
        s=session_from(self)
        if not s:self.json(401,{'error':'login_required'});return
        if not hmac.compare_digest(str(data.get('csrf','')),s['csrf']):self.json(403,{'error':'csrf_failed'});return
        if path=='/api/change-password':
            old=data.get('current_password');new=data.get('new_password')
            if not isinstance(old,str) or not isinstance(new,str) or not 10<=len(new)<=128:
                self.json(400,{'error':'invalid_fields'});return
            with db() as c:
                row=c.execute('SELECT password_hash,salt FROM users WHERE id=?',(s['id'],)).fetchone()
                if not row or not hmac.compare_digest(hash_pw(old,row['salt']),row['password_hash']):
                    self.json(401,{'error':'invalid_credentials'});return
                salt=secrets.token_hex(16)
                c.execute('UPDATE users SET password_hash=?,salt=? WHERE id=?',(hash_pw(new,salt),salt,s['id']))
                c.execute('DELETE FROM sessions WHERE user_id=? AND token_hash<>?',(s['id'],sign(self.headers.get('Cookie','').split('ms_session=',1)[-1].split(';',1)[0])))
            self.json(200,{'ok':True});return
        if path=='/api/profile':
            name=str(data.get('name','')).strip()
            if not 2<=len(name)<=100:
                self.json(400,{'error':'invalid_fields'});return
            with db() as c:c.execute('UPDATE users SET name=? WHERE id=?',(name,s['id']))
            self.json(200,{'ok':True,'name':name});return
        if path=='/api/logout':
            cookie=SimpleCookie();cookie.load(self.headers.get('Cookie',''))
            if cookie.get('ms_session'):
                with db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(sign(cookie['ms_session'].value),))
            self.json(200,{'ok':True},'ms_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return
        if path=='/api/notifications/read':
            ids=data.get('ids',[]); mark_all=bool(data.get('all',False))
            if mark_all:
                with db() as c:c.execute('UPDATE notifications SET is_read=1 WHERE user_id=?',(s['id'],))
            elif isinstance(ids,list) and ids and all(str(x).isdigit() for x in ids):
                with db() as c:c.executemany('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?',[(int(x),s['id']) for x in ids[:100]])
            else:self.json(400,{'error':'invalid_notification_request'});return
            self.json(200,{'ok':True});return
        if path=='/api/admin/notify':
            if not s['is_admin']:self.json(403,{'error':'admin_required'});return
            ar=str(data.get('title_ar','')).strip(); en=str(data.get('title_en','')).strip(); mar=str(data.get('message_ar','')).strip(); men=str(data.get('message_en','')).strip(); link=str(data.get('link','')).strip(); kind=str(data.get('type','announcement')).strip()
            if not 2<=len(ar)<=160 or not 2<=len(en)<=160 or not 2<=len(mar)<=1000 or not 2<=len(men)<=1000 or len(link)>500 or kind not in ('announcement','course','payment','exam','certificate','info'):self.json(400,{'error':'invalid_notification'});return
            with db() as c:notify_all_students(c,ar,en,mar,men,kind,link)
            self.json(201,{'ok':True});return
        if path.startswith('/api/admin/'):
            if not s['is_admin']:self.json(403,{'error':'admin_required'});return
            try:
                with db() as c:
                    if path=='/api/admin/medical-field':
                        fid=str(data.get('field_id','')).strip(); ar=str(data.get('name_ar','')).strip(); en=str(data.get('name_en','')).strip(); dar=str(data.get('description_ar','')).strip(); den=str(data.get('description_en','')).strip(); icon=str(data.get('icon','✚')).strip(); order=data.get('sort_order',0); active=data.get('active',True)
                        if not re.fullmatch(r'[a-z0-9_-]{2,60}',fid) or not 2<=len(ar)<=150 or not 2<=len(en)<=150 or len(dar)>1000 or len(den)>1000 or not icon or type(order) is not int or not 0<=order<=999 or type(active) is not bool: raise ValueError()
                        c.execute('INSERT INTO medical_fields(id,name_ar,name_en,description_ar,description_en,icon,sort_order,active) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name_ar=excluded.name_ar,name_en=excluded.name_en,description_ar=excluded.description_ar,description_en=excluded.description_en,icon=excluded.icon,sort_order=excluded.sort_order,active=excluded.active',(fid,ar,en,dar,den,icon,order,int(active)))
                    elif path=='/api/admin/medical-field-delete':
                        fid=str(data.get('field_id','')).strip()
                        if not c.execute('SELECT 1 FROM medical_fields WHERE id=?',(fid,)).fetchone(): raise ValueError()
                        if c.execute('SELECT 1 FROM course_fields WHERE field_id=? LIMIT 1',(fid,)).fetchone(): raise ValueError()
                        c.execute('DELETE FROM medical_fields WHERE id=?',(fid,))
                    elif path=='/api/admin/course':
                        cid=str(data.get('course_id','')).strip(); ar=str(data.get('title_ar','')).strip(); en=str(data.get('title_en','')).strip(); dar=str(data.get('description_ar','')).strip(); den=str(data.get('description_en','')).strip(); icon=str(data.get('icon','⚕')).strip(); kind=str(data.get('pricing_kind','free')).strip(); pub=data.get('published',False); fid=str(data.get('field_id','')).strip()
                        if not re.fullmatch(r'[a-z0-9_-]{2,60}',cid) or not 2<=len(ar)<=150 or not 2<=len(en)<=150 or len(dar)>2000 or len(den)>2000 or not icon or kind not in ('free','paid') or type(pub) is not bool or (fid and not c.execute('SELECT 1 FROM medical_fields WHERE id=? AND active=1',(fid,)).fetchone()): raise ValueError()
                        c.execute('INSERT INTO courses(id,title_ar,title_en,description_ar,description_en,icon,pricing_kind) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title_ar=excluded.title_ar,title_en=excluded.title_en,description_ar=excluded.description_ar,description_en=excluded.description_en,icon=excluded.icon,pricing_kind=excluded.pricing_kind',(cid,ar,en,dar,den,icon,kind))
                        c.execute('INSERT INTO course_settings(course_id,published) VALUES(?,?) ON CONFLICT(course_id) DO UPDATE SET published=excluded.published',(cid,int(pub)))
                        c.execute('DELETE FROM course_fields WHERE course_id=?',(cid,))
                        if fid: c.execute('INSERT INTO course_fields(course_id,field_id) VALUES(?,?)',(cid,fid))
                        c.execute('INSERT OR IGNORE INTO course_pricing(course_id,amount,currency,payment_instructions,updated_at) VALUES(?,?,?,?,?)',(cid,0,'SDG','تواصل مع الإدارة عبر واتساب لإتمام الدفع.',int(time.time())))
                    elif path=='/api/admin/course-delete':
                        cid=str(data.get('course_id','')).strip()
                        if cid not in course_ids(c): raise ValueError()
                        if c.execute('SELECT 1 FROM enrollments WHERE course_id=? LIMIT 1',(cid,)).fetchone(): raise ValueError()
                        c.execute('DELETE FROM courses WHERE id=?',(cid,))
                    elif path=='/api/admin/module':
                        mid=str(data.get('module_id','')).strip(); cid=str(data.get('course_id','')).strip(); ar=str(data.get('title_ar','')).strip(); en=str(data.get('title_en','')).strip(); order=data.get('sort_order',0)
                        if not re.fullmatch(r'[a-z0-9_-]{2,80}',mid) or cid not in course_ids(c) or not 2<=len(ar)<=150 or not 2<=len(en)<=150 or type(order) is not int or not 0<=order<=999: raise ValueError()
                        c.execute('INSERT INTO modules(id,course_id,title_ar,title_en,sort_order) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET course_id=excluded.course_id,title_ar=excluded.title_ar,title_en=excluded.title_en,sort_order=excluded.sort_order',(mid,cid,ar,en,order))
                    elif path=='/api/admin/module-delete':
                        mid=str(data.get('module_id','')).strip();
                        if not c.execute('SELECT id FROM modules WHERE id=?',(mid,)).fetchone(): raise ValueError()
                        c.execute('DELETE FROM modules WHERE id=?',(mid,))
                    elif path=='/api/admin/media-delete':
                        mid=str(data.get('media_id','')).strip()
                        row=c.execute('SELECT stored_name FROM media WHERE id=?',(mid,)).fetchone()
                        if not row: raise ValueError()
                        c.execute('UPDATE lessons SET media_id=NULL WHERE media_id=?',(mid,)); c.execute('DELETE FROM media WHERE id=?',(mid,))
                        try: (MEDIA/row['stored_name']).unlink(missing_ok=True)
                        except OSError: pass
                    elif path=='/api/admin/media-upload':
                        # handled below, outside JSON branch
                        raise ValueError()
                    elif path=='/api/admin/lesson':
                        lid=str(data.get('lesson_id','')).strip(); mid=str(data.get('module_id','')).strip(); ar=str(data.get('title_ar','')).strip(); en=str(data.get('title_en','')).strip(); typ=str(data.get('type','video')).strip(); dur=data.get('duration_min',1); dar=str(data.get('description_ar','')).strip(); den=str(data.get('description_en','')).strip(); url=str(data.get('resource_url','')).strip(); order=data.get('sort_order',0); media_id=str(data.get('media_id','')).strip() or None
                        if not re.fullmatch(r'[a-z0-9_-]{2,100}',lid) or not c.execute('SELECT id FROM modules WHERE id=?',(mid,)).fetchone() or not 2<=len(ar)<=180 or not 2<=len(en)<=180 or typ not in ('video','audio','pdf','image','text','quiz') or type(dur) is not int or not 1<=dur<=600 or len(dar)>3000 or len(den)>3000 or len(url)>1000 or type(order) is not int or not 0<=order<=999: raise ValueError()
                        if media_id and not c.execute('SELECT id FROM media WHERE id=?',(media_id,)).fetchone(): raise ValueError()
                        c.execute('INSERT INTO lessons(id,module_id,title_ar,title_en,type,duration_min,description_ar,description_en,resource_url,sort_order,media_id) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET module_id=excluded.module_id,title_ar=excluded.title_ar,title_en=excluded.title_en,type=excluded.type,duration_min=excluded.duration_min,description_ar=excluded.description_ar,description_en=excluded.description_en,resource_url=excluded.resource_url,sort_order=excluded.sort_order,media_id=excluded.media_id',(lid,mid,ar,en,typ,dur,dar,den,url,order,media_id))
                        if media_id: c.execute('UPDATE media SET lesson_id=? WHERE id=?',(lid,media_id))
                    elif path=='/api/admin/lesson-delete':
                        lid=str(data.get('lesson_id','')).strip();
                        if not c.execute('SELECT id FROM lessons WHERE id=?',(lid,)).fetchone(): raise ValueError()
                        c.execute('DELETE FROM lessons WHERE id=?',(lid,))
                    elif path=='/api/admin/enrollment':
                        uid=int(data['user_id']);cid=str(data['course_id']);status=data['status']
                        if status not in ('active','pending'):raise ValueError()
                        cur=c.execute('UPDATE enrollments SET status=? WHERE user_id=? AND course_id=?',(status,uid,cid))
                        if not cur.rowcount:raise ValueError()
                        if status=='active':
                            course_row=next((x for x in db_courses(c) if x['id']==cid),None)
                            if course_row: notify_user(c,uid,'تمت الموافقة على التسجيل','Enrollment approved',f"وافقت الإدارة على تسجيلك في {course_row['title_ar']}.",f"Your enrollment in {course_row['title_en']} has been approved.",'course',f'course.html?id={cid}')
                    elif path=='/api/admin/quiz':
                        cid=str(data.get('course_id',''));ar=str(data.get('title_ar','')).strip();en=str(data.get('title_en','')).strip();pub=data.get('published');passp=data.get('pass_percent',70);dur=data.get('duration_min',30);maxa=data.get('max_attempts',0);show=data.get('show_answers',True)
                        if cid not in course_ids(c) or not 2<=len(ar)<=150 or not 2<=len(en)<=150 or type(pub) is not bool or type(passp) is not int or not 1<=passp<=100 or type(dur) is not int or not 1<=dur<=240 or type(maxa) is not int or not 0<=maxa<=20 or type(show) is not bool:raise ValueError()
                        c.execute('INSERT INTO quizzes(course_id,title_ar,title_en,published,pass_percent,duration_min,max_attempts,show_answers) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(course_id) DO UPDATE SET title_ar=excluded.title_ar,title_en=excluded.title_en,published=excluded.published,pass_percent=excluded.pass_percent,duration_min=excluded.duration_min,max_attempts=excluded.max_attempts,show_answers=excluded.show_answers',(cid,ar,en,int(pub),passp,dur,maxa,int(show)))
                    elif path=='/api/admin/question':
                        qid=int(data['quiz_id']);prompt=str(data.get('prompt','')).strip();opts=data.get('options');correct=data.get('correct_index');explanation=str(data.get('explanation','')).strip()
                        if not c.execute('SELECT id FROM quizzes WHERE id=?',(qid,)).fetchone() or not 2<=len(prompt)<=1000 or not isinstance(opts,list) or len(opts)!=4 or any(not isinstance(o,str) or not 1<=len(o.strip())<=250 for o in opts) or type(correct)!=int or not 0<=correct<4 or len(explanation)>1000:raise ValueError()
                        c.execute('INSERT INTO questions(quiz_id,prompt,options_json,correct_index,explanation) VALUES(?,?,?,?,?)',(qid,prompt,json.dumps(opts,ensure_ascii=False),correct,explanation))
                    elif path=='/api/admin/question-delete':
                        qid=int(data['question_id']);c.execute('DELETE FROM questions WHERE id=?',(qid,))
                    elif path=='/api/admin/pricing':
                        cid=str(data.get('course_id',''));amount=data.get('amount',0);currency=str(data.get('currency','SDG')).strip().upper();instructions=str(data.get('payment_instructions','')).strip()
                        if cid not in course_ids(c) or type(amount) is not int or not 0<=amount<=1000000000 or not re.fullmatch(r'[A-Z]{3}',currency) or not 5<=len(instructions)<=2000: raise ValueError()
                        c.execute('INSERT INTO course_pricing(course_id,amount,currency,payment_instructions,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(course_id) DO UPDATE SET amount=excluded.amount,currency=excluded.currency,payment_instructions=excluded.payment_instructions,updated_at=excluded.updated_at',(cid,amount,currency,instructions,int(time.time())))
                    elif path=='/api/admin/payment':
                        pid=int(data['payment_id']);status=data.get('status')
                        if status not in ('approved','rejected','pending'): raise ValueError()
                        row=c.execute('SELECT user_id,course_id,status FROM payment_requests WHERE id=?',(pid,)).fetchone()
                        if not row: raise ValueError()
                        c.execute('UPDATE payment_requests SET status=?,reviewed_at=? WHERE id=?',(status,int(time.time()) if status!='pending' else None,pid))
                        if status=='approved':
                            c.execute('INSERT INTO enrollments(user_id,course_id,status,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET status=excluded.status',(row['user_id'],row['course_id'],'active',int(time.time())))
                        elif status=='rejected':
                            c.execute('INSERT INTO enrollments(user_id,course_id,status,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET status=excluded.status',(row['user_id'],row['course_id'],'pending',int(time.time())))
                        if status in ('approved','rejected'):
                            course_row=next((x for x in db_courses(c) if x['id']==row['course_id']),None)
                            if course_row:
                                ar='تم قبول طلب الدفع' if status=='approved' else 'تم رفض طلب الدفع'
                                en='Payment request approved' if status=='approved' else 'Payment request rejected'
                                mar=f"تمت مراجعة طلب الدفع للكورس {course_row['title_ar']}."
                                men=f"Your payment request for {course_row['title_en']} has been reviewed."
                                notify_user(c,row['user_id'],ar,en,mar,men,'payment','dashboard.html')
                    elif path=='/api/admin/certificate':
                        uid=int(data['user_id']);cid=str(data['course_id']);aid=int(data['attempt_id'])
                        match=c.execute('SELECT a.id,a.passed,a.percent,q.pass_percent FROM attempts a JOIN quizzes q ON q.id=a.quiz_id JOIN enrollments e ON e.user_id=a.user_id AND e.course_id=q.course_id WHERE a.id=? AND a.user_id=? AND q.course_id=? AND e.status="active"',(aid,uid,cid)).fetchone()
                        if not match or not match['passed']:raise ValueError()
                        existing=c.execute('SELECT id FROM certificates WHERE user_id=? AND course_id=?',(uid,cid)).fetchone()
                        if existing: raise ValueError()
                        cert_id=secrets.token_hex(12)
                        c.execute('INSERT INTO certificates(id,user_id,course_id,attempt_id,issued_at) VALUES(?,?,?,?,?)',(cert_id,uid,cid,aid,int(time.time())))
                        course_row=next((x for x in db_courses(c) if x['id']==cid),None)
                        if course_row: notify_user(c,uid,'تم إصدار شهادتك','Certificate issued',f"تم إصدار شهادة إتمامك لـ {course_row['title_ar']}.",f"Your certificate for {course_row['title_en']} has been issued.",'certificate',f'certificate.html?id={cert_id}')
                self.json(200,{'ok':True});return
            except (ValueError,KeyError,TypeError,sqlite3.IntegrityError):self.json(400,{'error':'invalid_admin_request'});return
        if path=='/api/payment/request':
            try:
                cid=str(data.get('course_id',''));method=str(data.get('method','')).strip();reference=str(data.get('reference','')).strip();note=str(data.get('note','')).strip()
                if method not in ('bank_transfer','mobile_money','whatsapp') or not 2<=len(reference)<=120 or len(note)>1000: raise ValueError()
                with db() as c:
                    course=next((x for x in db_courses(c) if x['id']==cid),None)
                    pub=c.execute('SELECT published FROM course_settings WHERE course_id=?',(cid,)).fetchone()
                    pricing=c.execute('SELECT amount,currency FROM course_pricing WHERE course_id=?',(cid,)).fetchone()
                    if not course or not pub or not pub['published'] or course['pricing_example']!='paid' or not pricing or pricing['amount']<=0: raise ValueError()
                    existing=c.execute("SELECT id,status FROM payment_requests WHERE user_id=? AND course_id=? AND status='pending' ORDER BY id DESC LIMIT 1",(s['id'],cid)).fetchone()
                    if existing: self.json(409,{'error':'payment_request_pending','payment_id':existing['id']});return
                    enrolled=c.execute('SELECT status FROM enrollments WHERE user_id=? AND course_id=?',(s['id'],cid)).fetchone()
                    if enrolled and enrolled['status']=='active': self.json(409,{'error':'already_enrolled'});return
                    cur=c.execute('INSERT INTO payment_requests(user_id,course_id,amount,currency,method,reference,note,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(s['id'],cid,pricing['amount'],pricing['currency'],method,reference,note,'pending',int(time.time())))
                    c.execute('INSERT INTO enrollments(user_id,course_id,status,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET status=excluded.status',(s['id'],cid,'pending',int(time.time())))
                    notify_user(c,s['id'],'تم استلام طلب الدفع','Payment request received',f"تم استلام طلب الدفع للكورس {course['title_ar']} وسيتم مراجعته من الإدارة.",f"Your payment request for {course['title_en']} has been received and is under review.",'payment','dashboard.html')
                self.json(201,{'ok':True,'payment_id':cur.lastrowid,'status':'pending','amount':pricing['amount'],'currency':pricing['currency']});return
            except (ValueError,KeyError,TypeError,sqlite3.IntegrityError): self.json(400,{'error':'invalid_payment_request'});return
        if path=='/api/quiz/submit':
            try:
                qid=int(data['quiz_id']);answers=data['answers'];started_at=int(data.get('started_at',0))
                if not isinstance(answers,dict):raise ValueError()
                now=int(time.time())
                with db() as c:
                    q=c.execute("SELECT q.* FROM quizzes q JOIN enrollments e ON e.course_id=q.course_id WHERE q.id=? AND q.published=1 AND e.user_id=? AND e.status='active'",(qid,s['id'])).fetchone()
                    questions=c.execute('SELECT id,correct_index,explanation,options_json FROM questions WHERE quiz_id=? ORDER BY id',(qid,)).fetchall()
                    used=c.execute('SELECT COUNT(*) n FROM attempts WHERE quiz_id=? AND user_id=?',(qid,s['id'])).fetchone()['n']
                    if not q or not questions or (q['max_attempts'] and used>=q['max_attempts']):raise ValueError()
                    total_lessons=c.execute('SELECT COUNT(*) n FROM lessons l JOIN modules m ON m.id=l.module_id WHERE m.course_id=?',(q['course_id'],)).fetchone()['n']
                    done_lessons=c.execute('SELECT COUNT(*) n FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],q['course_id'])).fetchone()['n']
                    if total_lessons and done_lessons<total_lessons:self.json(403,{'error':'lessons_incomplete','completed_lessons':done_lessons,'total_lessons':total_lessons});return
                    if started_at and (started_at>now+30 or now-started_at>q['duration_min']*60+15):self.json(400,{'error':'time_limit_exceeded'});return
                    if len(answers)!=len(questions) or any(str(r['id']) not in answers or type(answers[str(r['id'])])!=int or not 0<=answers[str(r['id'])]<4 for r in questions):raise ValueError()
                    score=sum(answers[str(r['id'])]==r['correct_index'] for r in questions);total=len(questions);percent=round(score*100/total);passed=percent>=q['pass_percent']
                    cur=c.execute('INSERT INTO attempts(quiz_id,user_id,score,total,percent,passed,created_at) VALUES(?,?,?,?,?,?,?)',(qid,s['id'],score,total,percent,int(passed),now))
                    attempt_id=cur.lastrowid
                    notify_user(c,s['id'],'نتيجة الاختبار','Quiz result',f'حصلت على {percent}% في الاختبار.',f'You scored {percent}% on the quiz.','exam','quiz.html')
                result={'attempt_id':attempt_id,'score':score,'total':total,'percent':percent,'passed':passed,'pass_percent':q['pass_percent'],'attempts_used':used+1,'max_attempts':q['max_attempts'],'note':'يمكن للإدارة مراجعة النتيجة وإصدار الشهادة.'}
                if q['show_answers']:
                    result['review']=[{'id':r['id'],'correct_index':r['correct_index'],'selected_index':answers[str(r['id'])],'correct':answers[str(r['id'])]==r['correct_index'],'explanation':r['explanation'],'options':json.loads(r['options_json'])} for r in questions]
                self.json(200,result);return
            except (ValueError,KeyError,TypeError):self.json(400,{'error':'invalid_quiz_submission'});return
        if path=='/api/progress/complete':
            cid=str(data.get('course_id',''));lesson_id=str(data.get('lesson_id',''))
            with db() as c: course=next((x for x in db_courses(c) if x['id']==cid),None)
            lesson=next((l for m in course.get('modules',[]) for l in m.get('lessons',[]) if l['id']==lesson_id),None) if course else None
            with db() as c: enrolled=c.execute("SELECT status FROM enrollments WHERE user_id=? AND course_id=?",(s['id'],cid)).fetchone()
            if not lesson or not enrolled or enrolled['status']!='active':self.json(403,{'error':'course_access_required'});return
            flat=[l for m in course.get('modules',[]) for l in m.get('lessons',[])]
            idx=next((i for i,l in enumerate(flat) if l['id']==lesson_id),-1)
            if idx<0:self.json(404,{'error':'lesson_not_found'});return
            with db() as c:
                previous=flat[idx-1]['id'] if idx else None
                if previous and not c.execute('SELECT 1 FROM lesson_progress WHERE user_id=? AND course_id=? AND lesson_id=?',(s['id'],cid,previous)).fetchone():
                    self.json(409,{'error':'previous_lesson_required','previous_lesson_id':previous});return
                c.execute('INSERT OR IGNORE INTO lesson_progress(user_id,course_id,lesson_id,completed_at) VALUES(?,?,?,?)',(s['id'],cid,lesson_id,int(time.time())))
            with db() as c: done=c.execute('SELECT COUNT(*) n FROM lesson_progress WHERE user_id=? AND course_id=?',(s['id'],cid)).fetchone()['n']
            total=sum(len(m.get('lessons',[])) for m in course.get('modules',[]))
            self.json(200,{'ok':True,'completed':done,'total':total,'percent':round(done*100/total) if total else 0});return
        cid=str(data.get('course_id',''))
        with db() as c:
            published=c.execute('SELECT published FROM course_settings WHERE course_id=?',(cid,)).fetchone()
            course=next((x for x in db_courses(c) if x['id']==cid),None)
        if course and (not published or not published['published']): course=None
        if not course:self.json(404,{'error':'course_unavailable'});return
        status='active' if course['pricing_example']=='free' else 'pending'
        with db() as c:
            c.execute('INSERT OR IGNORE INTO enrollments(user_id,course_id,status,created_at) VALUES(?,?,?,?)',(s['id'],cid,status,int(time.time())))
            if status=='active': notify_user(c,s['id'],'تم تفعيل التسجيل','Enrollment activated',f"تم تفعيل تسجيلك في {course['title_ar']}. يمكنك بدء التعلم الآن.",f"Your enrollment in {course['title_en']} is active. You can start learning now.",'course',f'course.html?id={cid}')
            else: notify_user(c,s['id'],'طلب التسجيل قيد المراجعة','Enrollment request pending',f"تم استلام طلب التسجيل في {course['title_ar']} وسيتم مراجعته من الإدارة.",f"Your enrollment request for {course['title_en']} has been received and is awaiting review.",'course','dashboard.html')
            pricing=c.execute('SELECT amount,currency,payment_instructions FROM course_pricing WHERE course_id=?',(cid,)).fetchone()
        if course['pricing_example']=='paid':
            self.json(200,{'ok':True,'status':'payment_required','amount':pricing['amount'] if pricing else 0,'currency':pricing['currency'] if pricing else 'SDG','payment_instructions':pricing['payment_instructions'] if pricing else ''});return
        self.json(200,{'ok':True,'status':'active'});return

if __name__=='__main__':
    init()
    if len(sys.argv)>1 and sys.argv[1]=='backup':
        backup=DATA/'backups';backup.mkdir(exist_ok=True)
        dest=backup/('medical-space-'+datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'.sqlite3')
        with db() as source,sqlite3.connect(dest) as target:source.backup(target)
        try:os.chmod(dest,0o600)
        except OSError:pass
        print('Database backup created:',dest);sys.exit(0)
    if len(sys.argv)>1 and sys.argv[1]=='promote-admin':
        import getpass,sys
        email=input('Existing student email to promote: ').strip().lower()
        if input('Type PROMOTE to confirm: ')!='PROMOTE':sys.exit('Cancelled')
        with db() as c:
            row=c.execute('UPDATE users SET is_admin=1 WHERE email=?',(email,))
            if not row.rowcount:sys.exit('User not found; register the account first')
            c.execute('DELETE FROM sessions WHERE user_id=(SELECT id FROM users WHERE email=?)',(email,))
        sys.exit('Admin enabled; log in again')
    print(f'MEDICAL SPACE production-capable server: http://{HOST}:{PORT}',flush=True)
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
