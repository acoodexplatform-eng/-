# Medical Space v3.4

إصدار v3.4 يركز على **SEO + Performance** مع الحفاظ على جميع وظائف v3.3.

## SEO
- عناوين ووصف صفحات عامة أفضل بالعربية، مع metadata أساسية للمشاركة.
- `robots` و`canonical` وOpen Graph وTwitter Card للصفحات العامة.
- الصفحات الخاصة بالحسابات والإدارة معلّمة `noindex,nofollow,noarchive`.
- مولّد `/sitemap.xml` ديناميكي يعتمد على البرامج المنشورة، ويُضاف كل كورس منشور كصفحة قابلة للاكتشاف.
- مولّد `/robots.txt` ديناميكي يضع رابط الـSitemap وفق النطاق الحالي.
- دعم تحديث metadata للكورس أثناء تحميل صفحة الكورس وتبديل اللغة.

## Performance
- Cache-busting للإصدارات المحلية للأصول (`?v=3.4`).
- Cache طويل للأصول الثابتة المرقّمة بالإصدار مع `immutable`.
- ضغط Gzip تلقائي لملفات HTML/CSS/JS/XML/TXT المتوافقة مع المتصفح.
- `preload` لملفات CSS الحرجة.
- `loading="lazy"` و`decoding="async"` للعناصر الصورية غير الحرجة.
- طبقة CSS خفيفة لتحسين التعامل مع الحركة وتقليل آثارها عند تفعيل `prefers-reduced-motion`.

## التشغيل المحلي
```bash
python server/app.py
```
ثم افتح `http://127.0.0.1:8000/`.

## إعداد النطاق للـSEO
عند النشر اضبط:
```env
PUBLIC_BASE_URL=https://your-domain.example
```
وإلا سيستخدم التطبيق الـHost الوارد في الطلب لبناء Sitemap وRobots.

هذه نسخة تطوير/تجهيز وليست إثباتًا أن الموقع منشور فعليًا على الإنترنت.
