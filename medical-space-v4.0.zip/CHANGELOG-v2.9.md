# CHANGELOG v2.9

## Administration Center
- Added admin overview statistics.
- Added student management/listing section.
- Added quick search and category filters.
- Added counts for students, courses, fields, enrollments, payments, attempts, certificates and media.
- Preserved all v2.8 medical field and course management features.
- Health version updated to 2.9.
