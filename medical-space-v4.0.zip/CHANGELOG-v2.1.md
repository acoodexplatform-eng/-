# MEDICAL SPACE v2.1 — Payment & Enrollment Workflow

## Implemented
- Added course pricing records with amount, currency, and payment instructions.
- Added manual payment-request workflow for paid courses.
- Added payment request states: pending, approved, rejected.
- Admin can configure price and payment instructions per course.
- Admin can review and approve/reject payment requests.
- Approval activates the student's paid-course enrollment.
- Student dashboard now shows payment requests.
- Paid-course pages route students to a dedicated payment/enrollment page.
- Added transaction/reference field and payment method selection.
- Kept free-course enrollment unchanged.
- Updated health version to 2.1.

## Important
This release implements a **manual payment workflow**, not a live payment gateway. No bank/mobile-money provider credentials or external payment API were supplied, so the system does not claim to process money automatically. A real gateway can be integrated in a later deployment-specific step.
