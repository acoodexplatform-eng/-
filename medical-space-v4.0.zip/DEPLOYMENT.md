# MEDICAL SPACE — Production Deployment Checklist

This package is a deployment-readiness build, not a claim that the site is already deployed.

## Required before public launch
1. Use HTTPS and set `COOKIE_SECURE=1`.
2. Put `MEDICAL_SPACE_DATA` outside the public web root.
3. Run behind a production WSGI/ASGI server or a reverse proxy rather than the built-in development server.
4. Set `PUBLIC_BASE_URL` to the real HTTPS origin so the generated robots.txt and sitemap.xml use the canonical domain.
5. Configure automated database backups and test restoring one.
6. Create a dedicated admin account and use a unique strong password.
7. Review the CSP and allowed external services after adding analytics, payment, email, or media providers.
8. Configure a real password-reset service before exposing password recovery to students.
9. Add a production payment provider only after the platform's payment workflow is approved.

## v1.7 verification notes
- Password change is included in the authenticated POST API allowlist.
- Student profile name updates use the existing session + CSRF protection.
- Fresh installations now create the database tables before expired-session cleanup.

## Local smoke test
```bash
python server/app.py
```
Then visit `http://127.0.0.1:8000` and check:
- `/api/health`
- registration/login/logout
- student dashboard
- admin dashboard
- quiz submission
- certificate PDF download

## Security notes
- Passwords use `scrypt` with per-user salts.
- Session tokens are stored hashed server-side.
- Authenticated mutations require a CSRF token.
- Security response headers are set by the application.
- Login attempts are rate-limited in memory; a production deployment should use a shared rate limiter at the reverse-proxy/application layer.
- Do not expose the `server/private` directory.

## v3.4 SEO/performance notes
- Public static assets are versioned with `?v=3.4` and may be cached for a long period.
- The built-in server applies Gzip to compatible text assets when the client advertises it.
- `/sitemap.xml` is generated from currently published courses; it is not a declaration that a public domain exists.
