# Medical Space v3.1

- Redesigned course/content learning experience.
- Added focused lesson viewer with video/audio/PDF/image/text rendering.
- Added previous/next lesson navigation.
- Added automatic move to the next unlocked lesson after completion.
- Added module completion indicators and active lesson state.
- Preserved sequential unlocking and quiz eligibility rules.
- Improved responsive/mobile learning UI.
