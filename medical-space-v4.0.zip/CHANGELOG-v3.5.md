# Medical Space v3.5

## SEO
- تحسين metadata للصفحات العامة: description/title/robots/canonical/Open Graph/Twitter Card.
- إضافة `assets/js/seo.js` لتحديث metadata ديناميكيًا مع اللغة والكورس.
- إضافة `/sitemap.xml` ديناميكي، يشمل الصفحات العامة والكورسات المنشورة.
- إضافة `/robots.txt` ديناميكي مع رابط Sitemap كامل.
- إضافة `noindex,nofollow,noarchive` للصفحات الخاصة بالحسابات والإدارة.

## Performance
- إصدار أصول CSS/JS/images عبر `?v=3.4` لتحسين التخزين المؤقت وتفادي الأصول القديمة.
- Cache headers طويلة للأصول الثابتة المرقّمة.
- Gzip تلقائي للأصول النصية الصغيرة والمتوسطة عند دعم المتصفح.
- CSS preload للأصول الحرجة.
- lazy loading/async decoding للصور غير الحرجة.
- طبقة أداء واحترام `prefers-reduced-motion`.

## Compatibility
- الحفاظ على وظائف التعلم، الاختبارات، الشهادات، الدفع اليدوي، الإشعارات، التقارير، ولوحات الطالب والإدارة.
- Health API أصبح v3.5.

## v3.5 Security hardening
- Expired-session cleanup.
- Global mutation rate limiting.
- Protected-media no-store policy.
- Upload rollback on database failure.
- API/protected-media noindex headers.
- Security audit documentation and production security checklist.
